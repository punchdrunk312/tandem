// Bob — Tandem's own mascot, drawn entirely in code (no image files).
//
// A rounded teal cube with an amber twin tucked behind him (the two squares of the
// Tandem logo), a little antenna whose bulb shows what is going on, big glossy eyes
// that follow the cursor, and a mouth that changes with his mood.
//
// The animation plumbing (tweens, look-at, blink, particles) is the generic part of
// Coucou's MIT-licensed engine. Everything you can see — shape, colours, face,
// hands, badges — is original to Tandem.

import { Ease, lerp, type EaseFn } from "../core/anim";
import { Sound } from "../core/sound";
import type { BotEmoteName, BotStateName } from "../core/layout";
import type { Look } from "../core/seasons";

export type EyeShape =
  | "pill" | "wide" | "dot" | "line" | "flat" | "happy" | "closed"
  | "spiral" | "heart" | "star" | "tired" | "wink" | "cup";

export type BadgeKind = "dots" | "bang" | "question" | "dot";

export interface Badge {
  kind: BadgeKind;
  color: RGB;
}

export type RGB = readonly [number, number, number]; // components 0…1

export type TweenKey = readonly [target: number, durationMs: number, ease: EaseFn];

interface Tween {
  prop: PropKey;
  keys: TweenKey[];
  index: number;
  from: number;
  startMs: number;
  onComplete?: () => void;
}

type PropKey =
  | "yaw" | "pitch" | "roll" | "tilt" | "open" | "sx" | "sy"
  | "oy" | "ox" | "tint" | "morph" | "hands" | "blush" | "es" | "badgeS";

interface BotStateCfg {
  color: RGB;
  tint: number;
  eye: EyeShape;
  mouth: MouthShape;
  badge: Badge | null;
  bounces: boolean;
  scans: boolean;
  breathes: boolean;
  zz: boolean;
  sweat: boolean;
  look: readonly [number, number] | null;
  tilt: number;
}

type MouthShape = "smile" | "grin" | "flat" | "o" | "wavy" | "tiny" | "hmm";

interface Particle {
  type: "heart" | "star" | "spark" | "sweat" | "z" | "note";
  x: number; y: number; vx: number; vy: number;
  age: number; life: number; rot: number; size: number;
}

// ── Look ──────────────────────────────────────────────────────────────────────

const TEAL_TOP: RGB = [0.45, 0.93, 0.85]; // light, top-left
const TEAL_BOTTOM: RGB = [0.08, 0.72, 0.64]; // deep, bottom-right
const AMBER: RGB = [0.98, 0.75, 0.14];
const AMBER_DEEP: RGB = [0.93, 0.55, 0.08];
const INK = "rgb(10,28,34)";

const C = {
  idle: [0.18, 0.83, 0.75] as RGB,
  working: [0.231, 0.62, 1] as RGB,
  thinking: [0.545, 0.361, 0.965] as RGB,
  searching: [0.388, 0.396, 0.949] as RGB,
  approval: [0.961, 0.647, 0.141] as RGB,
  question: [0.133, 0.827, 0.933] as RGB,
  error: [0.957, 0.314, 0.369] as RGB,
  finished: [0.204, 0.831, 0.6] as RGB,
  ratelimit: [0.984, 0.573, 0.235] as RGB,
  sleeping: [0.58, 0.635, 0.722] as RGB,
  dizzy: [0.957, 0.447, 0.714] as RGB,
};

const base = {
  bounces: false, scans: false, breathes: false, zz: false, sweat: false,
  look: null, tilt: 0,
};

export const BOT_STATES: Record<BotStateName, BotStateCfg> = {
  idle: { ...base, color: C.idle, tint: 0, eye: "pill", mouth: "smile", badge: null },
  working: { ...base, color: C.working, tint: 0.5, eye: "pill", mouth: "smile", badge: { kind: "dots", color: C.working } },
  thinking: { ...base, color: C.thinking, tint: 0.5, eye: "pill", mouth: "hmm", badge: { kind: "dots", color: C.thinking }, look: [0.55, 0.55] },
  searching: { ...base, color: C.searching, tint: 0.5, eye: "pill", mouth: "tiny", badge: { kind: "dots", color: C.searching }, scans: true },
  approval: { ...base, color: C.approval, tint: 0.55, eye: "wide", mouth: "o", badge: { kind: "bang", color: C.approval }, bounces: true },
  question: { ...base, color: C.question, tint: 0.5, eye: "pill", mouth: "hmm", badge: { kind: "question", color: C.question }, tilt: 0.17 },
  error: { ...base, color: C.error, tint: 0.6, eye: "flat", mouth: "flat", badge: { kind: "dot", color: C.error } },
  finished: { ...base, color: C.finished, tint: 0.2, eye: "happy", mouth: "grin", badge: { kind: "dot", color: C.finished } },
  ratelimit: { ...base, color: C.ratelimit, tint: 0.5, eye: "tired", mouth: "wavy", badge: { kind: "dot", color: C.ratelimit }, sweat: true },
  sleeping: { ...base, color: C.sleeping, tint: 0.45, eye: "closed", mouth: "tiny", badge: null, breathes: true, zz: true },
  dizzy: { ...base, color: C.dizzy, tint: 0.5, eye: "spiral", mouth: "wavy", badge: null },
};

/** State → sound. */
export const STATE_SOUND: Partial<Record<BotStateName, string>> = {
  working: "work", thinking: "think", searching: "search", approval: "approval",
  question: "question", error: "error", finished: "finish", ratelimit: "rate",
  sleeping: "sleep", dizzy: "dizzy",
};

const EMOTE_EYE: Record<BotEmoteName, EyeShape> = {
  love: "heart", surprised: "dot", proud: "star", wink: "wink",
  yawn: "tired", happy: "happy", annoyed: "line",
};

// ── Small helpers ─────────────────────────────────────────────────────────────

const now = () => performance.now() / 1000;

export function hexToRGB(hex: string): RGB {
  const h = hex.replace("#", "");
  const v = parseInt(h, 16);
  return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
}

const rgba = (c: RGB, a = 1) =>
  `rgba(${Math.round(c[0] * 255)},${Math.round(c[1] * 255)},${Math.round(c[2] * 255)},${a})`;

const mix3 = (a: RGB, b: RGB, t: number): RGB => [
  lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t),
];

function roundRectPath(x: CanvasRenderingContext2D, X: number, Y: number, W: number, H: number, R: number) {
  const r = Math.max(0, Math.min(R, W / 2, H / 2));
  x.beginPath();
  x.moveTo(X + r, Y);
  x.arcTo(X + W, Y, X + W, Y + H, r);
  x.arcTo(X + W, Y + H, X, Y + H, r);
  x.arcTo(X, Y + H, X, Y, r);
  x.arcTo(X, Y, X + W, Y, r);
  x.closePath();
}

function heartPath(x: CanvasRenderingContext2D, s: number) {
  x.beginPath();
  x.moveTo(0, s * 0.38);
  x.bezierCurveTo(-s * 1.05, -s * 0.15, -s * 0.5, -s * 0.95, 0, -s * 0.38);
  x.bezierCurveTo(s * 0.5, -s * 0.95, s * 1.05, -s * 0.15, 0, s * 0.38);
  x.closePath();
}

function starPath(x: CanvasRenderingContext2D, ro: number, ri: number) {
  x.beginPath();
  for (let i = 0; i < 10; i++) {
    const r = i % 2 ? ri : ro;
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    x.lineTo(Math.cos(a) * r, Math.sin(a) * r);
  }
  x.closePath();
}

/** A colour a little lighter (k > 0) or darker (k < 0). */
function shade(hex: string, k: number): string {
  const n = parseInt(hex.slice(1), 16);
  const ch = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k)));
  return `rgb(${ch[0]},${ch[1]},${ch[2]})`;
}

const FONT = `system-ui, "Segoe UI Variable Text", "Segoe UI", sans-serif`;

// ── Engine ────────────────────────────────────────────────────────────────────

export class Bob {
  isMini = false;
  /** Liquid Glass: a jelly Bob that catches the light (on the glass bar). */
  glass = false;
  /** Optional solid body colour (unused by Tandem; null = Bob's own teal). */
  bodyColor: RGB | null = null;

  // Animated state (BotEngine `s`)
  yaw = 0; pitch = 0; roll = 0; tilt = 0; open = 1;
  sx = 1; sy = 1; oy = 0; ox = 0;
  tint = 0; morph = 0; hands = 0; blush = 0; es = 1; badgeS = 0;

  // Targets
  tgYaw = 0; tgPitch = 0; tgTilt = 0; tgSy = 1; tgSx = 1; tgEs = 1;

  /** Extra canvas height above the body so hearts can fly out without clipping. */
  particleOverhang = 0;

  // Mouth spring (fraction of R)
  slotH = 0; slotHTarget = 0; slotHVel = 0; isChewing = false;

  col: RGB = C.idle;
  colT: RGB = C.idle;

  state: BotStateName = "idle";
  cfg: BotStateCfg = BOT_STATES.idle;

  eyeOverride: EyeShape | null = null;
  eyeOverrideUntil = 0;
  permanentEye: EyeShape | null = null;
  permanentEmote: BotEmoteName | null = null;
  miniNextBehavior = 0;

  badge: Badge | null = null;
  private badgeKey = "none";
  private badgeToken = 0;

  private tweens = new Map<PropKey, Tween>();
  private locks = new Set<PropKey>();
  private particles: Particle[] = [];

  /** Where the cursor is, −1…1. Positive Y means *up* (the island already flips it). */
  lookX = 0;
  lookY = 0;

  // Life: eye saccades, antenna springs, idle behaviours
  private sacX = 0; private sacY = 0; private sacTX = 0; private sacTY = 0; private sacNext = 0;
  private antA = 0; private antV = 0; private antS = 1; private antSV = 0;
  private prevOx = 0; private prevOy = 0;
  private nextIdle = now() + 3;
  /** True while the bar is open and someone can see him: only then does he fidget and
   *  breathe. When it is false nothing animates by itself, so a closed bar costs nothing. */
  ambient = true;
  /** Eyebrows: [left y, left tilt, right y, right tilt, opacity], eased towards a pose. */
  private brow = [0, 0, 0, 0, 0];
  mouthOverride: MouthShape | null = null;
  mouthUntil = 0;

  lastTime = now();
  private t0 = now() - Math.random() * 5;
  private nextBlink = now() + 1.5 + Math.random() * 2;
  waveUntil = 0;
  waveStart = 0;
  private greetToken = 0;
  private lastAmbient = 0;
  private slapTimes: number[] = [];
  private miniLookTarget = { x: 0, y: 0 };
  private miniLookNextTime = 0;

  /** Fired when three slaps land inside 1.7 s (→ dizzy + confused view). */
  onDizzy: (() => void) | null = null;

  /** What he wears (the season, a special day), or null for plain Bob. */
  look: Look | null = null;
  /** Where his antenna bulb was last drawn (for the spring flower). */
  private bulbAt = { x: 0, y: 0, r: 0 };
  /** Quick boops in a row (four → dizzy). */
  private boopTimes: number[] = [];

  // ── Public API ──────────────────────────────────────────────────────────────

  setState(next: BotStateName, force = false) {
    if (this.state === next && !force) return;
    const prev = this.state;
    this.state = next;
    this.cfg = BOT_STATES[next];
    this.colT = this.cfg.color;
    if (!this.locks.has("tint")) this.tint = this.cfg.tint;
    if (!this.locks.has("tilt")) this.tgTilt = this.cfg.tilt;
    this.setBadge(this.cfg.badge);

    switch (next) {
      case "finished":
        this.doRoll(950, 1);
        setTimeout(() => this.emit("spark", 5), 500);
        break;
      case "error":
        this.anim("ox", [
          [0.08, 50, Ease.out], [-0.08, 70, Ease.inOut],
          [0.05, 70, Ease.inOut], [0, 90, Ease.out],
        ]);
        break;
      case "approval":
        this.anim("oy", [[-0.2, 150, Ease.out], [0, 300, Ease.back]]);
        break;
      case "dizzy":
        this.doRoll(1300, 2);
        break;
      case "question":
        this.blink();
        break;
      case "ratelimit":
        this.emit("sweat", 1);
        break;
      default:
        if (prev !== "idle" || next !== "idle") this.blink();
    }
  }

  setBadge(b: Badge | null) {
    const key = b ? `${b.kind}-${b.color.join(",")}` : "none";
    if (key === this.badgeKey) return;
    this.badgeKey = key;
    const tok = ++this.badgeToken;
    this.anim("badgeS", [[0, 90, Ease.inOut]]);
    setTimeout(() => {
      if (tok !== this.badgeToken) return;
      this.badge = b;
      if (b) this.anim("badgeS", [[1, 280, Ease.back]]);
    }, 100);
  }

  blink() {
    if (this.locks.has("open")) return;
    this.anim("open", [[0.06, 70, Ease.inOut], [1, 130, Ease.out]]);
  }

  squash() {
    this.anim("sy", [[0.78, 70, Ease.out], [1.1, 130, Ease.out], [1, 170, Ease.inOut]]);
    this.anim("sx", [[1.16, 70, Ease.out], [0.95, 130, Ease.out], [1, 170, Ease.inOut]]);
  }

  /** Mailbox swallow — opens the slot, chews, then closes. */
  gulp() {
    this.slotHTarget = 0.42;
    setTimeout(() => {
      this.slotHTarget = 0;
      this.isChewing = true;
      setTimeout(() => { this.isChewing = false; }, 800);
    }, 460);
    this.anim("sy", [[0.78, 80, Ease.out], [1.18, 130, Ease.out], [1, 220, Ease.back]]);
    this.anim("sx", [[1.28, 80, Ease.out], [0.92, 130, Ease.out], [1, 220, Ease.back]]);
    this.blink();
  }

  /** A click on him: a giggle and a wobble. Four quick ones and he gets dizzy. */
  boop() {
    this.interruptGreet();
    if (this.state === "dizzy") return;
    const t = now();
    this.boopTimes = this.boopTimes.filter((s) => t - s < 1.6);
    this.boopTimes.push(t);
    this.squash();
    this.kick(-8);
    if (this.boopTimes.length >= 4) {
      this.boopTimes = [];
      this.onDizzy?.();
      return;
    }
    Sound.play("boop");
    this.eyeOverride = "happy";
    this.eyeOverrideUntil = t + 0.7;
    this.blush = Math.min(1, this.blush + 0.5);
    setTimeout(() => Sound.play("giggle"), 110);
  }

  /** Being petted: eyes closed happily, a blush, a purr and a few hearts. */
  pet() {
    if (this.state === "dizzy") return;
    this.eyeOverride = "happy";
    this.eyeOverrideUntil = now() + 1.6;
    this.blush = 1;
    this.emit("heart", 3);
    Sound.play("purr");
  }

  slap() {
    this.interruptGreet();
    if (this.state === "dizzy") return;
    const t = now();
    this.slapTimes = this.slapTimes.filter((s) => t - s < 1.7);
    this.slapTimes.push(t);
    Sound.play("slap");
    this.squash();
    this.kick(-14);
    if (this.slapTimes.length >= 3) {
      this.slapTimes = [];
      this.onDizzy?.();
    } else {
      this.eyeOverride = "line";
      this.eyeOverrideUntil = t + 0.8;
      setTimeout(() => Sound.play("annoyed"), 60);
    }
  }

  doRoll(durationMs: number, turns: number) {
    this.roll = 0;
    this.anim("roll", [[Math.PI * 2 * turns, durationMs, Ease.inOut]], () => { this.roll = 0; });
  }

  /** Peek wave (hello). */
  greet() {
    const t = now();
    const tok = ++this.greetToken;
    this.waveStart = t + 0.45;
    this.waveUntil = t + 1.55;

    this.eyeOverride = "happy";
    this.eyeOverrideUntil = t + 2.0;
    this.anim("oy", [[-0.06, 220, Ease.out], [0.0, 220, Ease.back]]);

    setTimeout(() => {
      if (this.greetToken !== tok) return;
      this.anim("hands", [[1, 280, Ease.out]]);
      this.anim("sy", [[0.95, 100, Ease.out], [1.0, 260, Ease.back]]);
      this.anim("sx", [[1.04, 100, Ease.out], [1.0, 260, Ease.back]]);
      Sound.play("greet");
    }, 250);

    setTimeout(() => { if (this.greetToken === tok) this.blink(); }, 550);
    setTimeout(() => { if (this.greetToken === tok) this.blink(); }, 1500);
    setTimeout(() => {
      if (this.greetToken !== tok) return;
      this.waveUntil = 0;
      this.anim("hands", [[0, 200, Ease.inOut]]);
    }, 1550);
    setTimeout(() => {
      if (this.greetToken !== tok) return;
      this.eyeOverride = "happy";
      this.eyeOverrideUntil = now() + 0.3;
    }, 1750);
  }

  interruptGreet() {
    if (this.hands <= 0.01 && now() >= this.waveUntil) return;
    this.greetToken++;
    this.waveUntil = 0;
    this.waveStart = 0;
    this.anim("hands", [[0, 150, Ease.inOut]]);
  }

  setPermanentEmote(emote: BotEmoteName | null) {
    this.permanentEmote = emote;
    if (emote === "wink") {
      this.miniNextBehavior = now() + 0.8 + Math.random() * 1.7;
      return;
    }
    this.permanentEye = emote ? EMOTE_EYE[emote] : null;
    if (this.permanentEye) {
      this.eyeOverride = this.permanentEye;
      this.eyeOverrideUntil = Number.POSITIVE_INFINITY;
    } else if (this.eyeOverrideUntil === Number.POSITIVE_INFINITY) {
      this.eyeOverride = null;
      this.eyeOverrideUntil = 0;
    }
    this.miniNextBehavior = now() + 0.8 + Math.random() * 1.7;
  }

  triggerEmote(emote: BotEmoteName, duration = 1.8) {
    const t = now();
    this.eyeOverride = EMOTE_EYE[emote];
    this.eyeOverrideUntil = t + duration;

    switch (emote) {
      case "love":
        this.anim("blush", [
          [1, 300, Ease.out], [1, (duration - 0.6) * 1000, Ease.lin], [0, 300, Ease.inOut],
        ]);
        this.emit("heart", 4);
        this.anim("oy", [[-0.1, 160, Ease.out], [0, 300, Ease.back]]);
        this.kick(10);
        break;
      case "surprised":
        this.anim("oy", [[-0.3, 140, Ease.out], [0, 380, Ease.back]]);
        this.anim("es", [[1.25, 120, Ease.out], [1, 500, Ease.inOut]]);
        break;
      case "proud":
        this.emit("star", 5);
        this.anim("tilt", [
          [-0.14, 220, Ease.out], [-0.14, (duration - 0.5) * 1000, Ease.lin], [0, 280, Ease.inOut],
        ]);
        this.anim("blush", [
          [0.7, 250, Ease.out], [0.7, (duration - 0.5) * 1000, Ease.lin], [0, 300, Ease.inOut],
        ]);
        break;
      case "wink":
        this.anim("tilt", [
          [0.12, 160, Ease.out], [0.12, (duration - 0.4) * 1000, Ease.lin], [0, 240, Ease.inOut],
        ]);
        break;
      case "yawn":
        this.anim("sy", [[1.12, 500, Ease.inOut], [1, 500, Ease.inOut]]);
        this.anim("sx", [[0.94, 500, Ease.inOut], [1, 500, Ease.inOut]]);
        setTimeout(() => { this.eyeOverride = "closed"; this.emit("z", 2); }, 700);
        break;
      case "happy":
        this.anim("blush", [[0.6, 200, Ease.out], [0, 600, Ease.inOut]]);
        this.hop(0.22);
        break;
      case "annoyed":
        this.eyeOverride = "line";
        this.eyeOverrideUntil = t + 0.8;
        setTimeout(() => Sound.play("annoyed"), 60);
        break;
    }
  }

  emit(type: Particle["type"], count: number) {
    for (let i = 0; i < count; i++) {
      const isZ = type === "z";
      this.particles.push({
        type,
        x: (Math.random() - 0.5) * 0.9 + (isZ ? 0.55 : 0),
        y: -0.7 - Math.random() * 0.2,
        vx: (Math.random() - 0.5) * 0.35 + (isZ ? 0.18 : 0),
        vy: -(0.45 + Math.random() * 0.35),
        age: -i * 0.14,
        life: 1.3 + Math.random() * 0.5,
        rot: Math.random() * Math.PI * 2,
        size: 0.15 + Math.random() * 0.08,
      });
    }
  }

  animateMorph(target: number, durationMs?: number) {
    const dur = durationMs ?? (target > 0.5 ? 550 : 650);
    this.anim("morph", [[target, dur, Ease.inOut]]);
  }

  resetMorph() {
    this.tweens.delete("morph");
    this.locks.delete("morph");
    this.morph = 0;
  }

  /** True while anything is still moving — lets the island stop its RAF loop. */
  get busy(): boolean {
    return (
      this.ambient ||
      this.tweens.size > 0 ||
      this.particles.length > 0 ||
      this.cfg.bounces || this.cfg.scans || this.cfg.breathes || this.cfg.zz || this.cfg.sweat ||
      this.isMini ||
      Math.abs(this.tgYaw - this.yaw) > 0.002 ||
      Math.abs(this.tgPitch - this.pitch) > 0.002 ||
      Math.abs(this.tgTilt - this.tilt) > 0.002 ||
      Math.abs(this.tgSy - this.sy) > 0.002 ||
      Math.abs(this.tgSx - this.sx) > 0.002 ||
      Math.abs(this.tgEs - this.es) > 0.002 ||
      this.slotH > 0.001 || Math.abs(this.slotHVel) > 0.001 ||
      Math.abs(this.col[0] - this.colT[0]) > 0.003 ||
      Math.abs(this.col[1] - this.colT[1]) > 0.003 ||
      Math.abs(this.col[2] - this.colT[2]) > 0.003
    );
  }

  // ── Tweens ──────────────────────────────────────────────────────────────────

  anim(prop: PropKey, keys: TweenKey[], onComplete?: () => void) {
    this.tweens.set(prop, {
      prop, keys, index: 0, from: this[prop], startMs: performance.now(), onComplete,
    });
    this.locks.add(prop);
  }

  // ── Update ──────────────────────────────────────────────────────────────────

  update(dt: number) {
    const n = now();
    const nowMs = performance.now();

    for (const tw of [...this.tweens.values()]) {
      const k = tw.keys[tw.index];
      const p = Math.min(1, Math.max(0, (nowMs - tw.startMs) / k[1]));
      this[tw.prop] = tw.from + (k[0] - tw.from) * k[2](p);
      if (p >= 1) {
        tw.from = k[0];
        tw.index += 1;
        tw.startMs = nowMs;
        if (tw.index >= tw.keys.length) {
          this.tweens.delete(tw.prop);
          this.locks.delete(tw.prop);
          tw.onComplete?.();
        }
      }
    }

    const t = n - this.t0;
    let ty = this.lookX * 0.62;
    let tp = this.lookY * 0.5;

    if (this.cfg.look) {
      ty = ty * 0.35 + this.cfg.look[0] * 0.55;
      tp = tp * 0.3 + this.cfg.look[1] * 0.5;
    }
    if (this.cfg.scans) {
      ty = Math.sin(t * 2.6) * 0.6;
      tp = -0.06;
    }
    if (this.state === "sleeping") { ty = 0; tp = -0.14; }
    if (this.state === "dizzy") { ty = Math.sin(t * 9) * 0.25; }

    // Mini bots never follow the mouse — they wander.
    if (this.isMini && !this.cfg.look && !this.cfg.scans && this.state !== "sleeping" && this.state !== "dizzy") {
      if (n > this.miniLookNextTime) {
        this.miniLookTarget = {
          x: -0.88 + Math.random() * 1.76,
          y: -0.55 + Math.random() * 1.0,
        };
        this.miniLookNextTime = n + 0.5 + Math.random() * 1.5;
      }
      ty = this.miniLookTarget.x * 0.62;
      tp = this.miniLookTarget.y * 0.5;
    }

    this.tgYaw = ty;
    this.tgPitch = tp;
    this.tgTilt = this.cfg.tilt;

    if (n > this.waveStart && n < this.waveUntil) {
      const wt = n - this.waveStart;
      this.tgTilt = -0.06 + Math.sin(2 * Math.PI * 1.2 * wt) * 0.07;
    }

    const bounce = this.cfg.bounces ? -Math.abs(Math.sin(t * 5.2)) * 0.07 : 0;
    const kGen = 1 - Math.pow(0.0008, dt);
    if (!this.locks.has("oy")) this.oy += (bounce - this.oy) * kGen;

    // Small body language per state.
    if (this.state === "working") this.tgTilt = Math.sin(t * 6) * 0.025;
    else if (this.state === "thinking") this.tgTilt = Math.sin(t * 1.4) * 0.05 + 0.03;
    else if (this.state === "approval") this.tgTilt = Math.sin(t * 5.2) * 0.04;

    if (this.cfg.breathes) {
      const amp = this.isMini ? 0.07 : 0.035;
      this.tgSy = 1 + Math.sin(t * 1.8) * amp;
      this.tgSx = 1 - Math.sin(t * 1.8) * amp * 0.57;
    } else if (this.isMini) {
      this.tgSy = 1 + Math.sin(t * 2.2) * 0.04;
      this.tgSx = 1 - Math.sin(t * 2.2) * 0.02;
    } else {
      // A slow breath, so he is never perfectly still.
      const b = this.ambient ? Math.sin(t * 1.7) : 0;
      this.tgSy = 1 + b * 0.014;
      this.tgSx = 1 - b * 0.008;
    }

    if (this.isMini && n > this.miniNextBehavior) this.doMiniBehaviorLoop();

    const kLook = 1 - Math.pow(0.0025, dt);
    if (!this.locks.has("yaw")) this.yaw += (this.tgYaw - this.yaw) * kLook;
    if (!this.locks.has("pitch")) this.pitch += (this.tgPitch - this.pitch) * kLook;
    if (!this.locks.has("tilt")) this.tilt += (this.tgTilt - this.tilt) * kGen;
    if (!this.locks.has("sy")) this.sy += (this.tgSy - this.sy) * kGen;
    if (!this.locks.has("sx")) this.sx += (this.tgSx - this.sx) * kGen;
    if (!this.locks.has("es")) this.es += (this.tgEs - this.es) * kGen;

    this.col = mix3(this.col, this.colT, 1 - Math.pow(0.002, dt));

    // Eyes never sit perfectly still: tiny, lazy glances.
    if (n > this.sacNext) {
      this.sacTX = (Math.random() - 0.5) * 0.28;
      this.sacTY = (Math.random() - 0.5) * 0.2;
      this.sacNext = n + 0.5 + Math.random() * 1.7;
    }
    const kSac = 1 - Math.pow(0.0004, dt);
    this.sacX += (this.sacTX - this.sacX) * kSac;
    this.sacY += (this.sacTY - this.sacY) * kSac;

    // Antenna: two springs. It leans against the body's motion and stretches when he jumps.
    if (dt > 0) {
      const vx = (this.ox - this.prevOx) / dt;
      const vy = (this.oy - this.prevOy) / dt;
      this.prevOx = this.ox;
      this.prevOy = this.oy;
      const aTarget = -this.tilt * 1.1 + this.yaw * 0.08;
      const accA = -140 * (this.antA - aTarget) - 8 * this.antV - vx * 2.2;
      this.antV += accA * dt;
      this.antA += this.antV * dt;
      const sTarget = 1;
      const accS = -170 * (this.antS - sTarget) - 9 * this.antSV + vy * 1.6;
      this.antSV += accS * dt;
      this.antS = Math.max(0.35, Math.min(1.7, this.antS + this.antSV * dt));
    }

    const bt = this.browTarget();
    const kb = 1 - Math.pow(0.0006, dt);
    for (let i = 0; i < 5; i++) this.brow[i] += (bt[i] - this.brow[i]) * kb;

    if (n > this.nextIdle) this.idleAct(n);
    if (!this.ambient) { this.sacTX = 0; this.sacTY = 0; }

    if (this.mouthOverride && n > this.mouthUntil) this.mouthOverride = null;

    if (n > this.nextBlink) {
      if (this.state !== "sleeping" && this.state !== "dizzy") {
        this.blink();
        if (Math.random() < 0.22) setTimeout(() => this.blink(), 230);
      }
      this.nextBlink = n + 2.2 + Math.random() * 3.2;
    }

    if (this.eyeOverride && n > this.eyeOverrideUntil) {
      this.eyeOverride = this.permanentEye;
      if (this.permanentEye) this.eyeOverrideUntil = Number.POSITIVE_INFINITY;
    }

    if (n - this.lastAmbient > 1.3) {
      this.lastAmbient = n;
      if (this.cfg.zz) this.emit("z", 1);
      if (!this.isMini && this.cfg.sweat && Math.random() < 0.5) this.emit("sweat", 1);
    }

    for (const p of this.particles) p.age += dt;
    this.particles = this.particles.filter((p) => p.age < p.life);

    // Mouth slot spring — ω₀ = 2π/0.25, ζ = 0.6
    const omega = (2 * Math.PI) / 0.25;
    const zeta = 0.6;
    const acc = omega * omega * (this.slotHTarget - this.slotH) - 2 * zeta * omega * this.slotHVel;
    this.slotHVel += acc * dt;
    this.slotH = Math.max(0, this.slotH + this.slotHVel * dt);

    this.lastTime = n;
  }

  /** The eyebrow pose for the current mood. y is in units of R (up is positive). */
  private browTarget(): number[] {
    const eye = this.eyeOverride ?? this.cfg.eye;
    if (this.morph > 0.4) return [0.1, -0.08, 0.1, 0.08, 0.7];
    switch (eye) {
      case "closed": case "spiral": case "heart": case "star": case "cup":
        return [0, 0, 0, 0, 0];
      case "happy": return [0.17, -0.12, 0.17, 0.12, 0.85];
      case "wide": case "dot": return [0.26, -0.06, 0.26, 0.06, 0.9];
      case "flat": case "line": return [-0.02, 0.5, -0.02, -0.5, 0.9];
      case "tired": return [0.03, -0.32, 0.03, 0.32, 0.85];
      case "wink": return [0.06, -0.1, 0.22, 0.1, 0.85];
      default:
        if (this.state === "thinking") return [0.03, 0, 0.22, -0.22, 0.85];
        if (this.state === "question") return [0.0, 0.18, 0.24, -0.28, 0.85];
        if (this.state === "working") return [0.05, 0.12, 0.05, -0.12, 0.8];
        return [0.07, -0.1, 0.07, 0.1, 0.7];
    }
  }

  /** Kicks the antenna so it wobbles. */
  kick(v: number) {
    this.antV += v;
  }

  /** A little hop. */
  hop(height = 0.28) {
    if (this.locks.has("oy")) return;
    this.anim("oy", [[-height, 150, Ease.out], [0.03, 190, Ease.inOut], [0, 150, Ease.back]]);
    this.anim("sy", [[0.86, 70, Ease.out], [1.14, 140, Ease.out], [0.92, 150, Ease.inOut], [1, 170, Ease.back]]);
    this.anim("sx", [[1.12, 70, Ease.out], [0.92, 140, Ease.out], [1.05, 150, Ease.inOut], [1, 170, Ease.back]]);
    this.kick(6);
  }

  /** Something to do every few seconds while nothing else is going on. */
  private idleAct(n: number) {
    this.nextIdle = n + 4 + Math.random() * 5;
    const calm =
      this.ambient && this.state === "idle" && !this.isMini && this.morph < 0.05 && this.hands < 0.05 &&
      !this.eyeOverride && this.locks.size === 0;
    if (!calm) return;
    const r = Math.random();
    if (r < 0.26) {
      this.hop();
    } else if (r < 0.46) {
      // Looks around the room.
      this.anim("yaw", [[-0.85, 300, Ease.inOut], [-0.85, 260, Ease.lin], [0.85, 520, Ease.inOut], [0.85, 260, Ease.lin], [0, 360, Ease.inOut]]);
      this.anim("pitch", [[0.12, 400, Ease.inOut], [-0.05, 700, Ease.inOut], [0, 400, Ease.inOut]]);
    } else if (r < 0.60) {
      this.anim("tilt", [[0.13, 90, Ease.out], [-0.12, 140, Ease.inOut], [0.08, 120, Ease.inOut], [-0.04, 110, Ease.inOut], [0, 130, Ease.out]]);
      this.kick(-8);
    } else if (r < 0.70) {
      // A stretch.
      this.anim("sy", [[1.13, 420, Ease.inOut], [1, 420, Ease.inOut]]);
      this.anim("sx", [[0.93, 420, Ease.inOut], [1, 420, Ease.inOut]]);
      this.mouthOverride = "o";
      this.mouthUntil = n + 0.8;
    } else if (r < 0.80) {
      this.blink();
      setTimeout(() => this.blink(), 210);
    } else if (r < 0.88) {
      this.triggerEmote("wink", 1.1);
    } else if (r < 0.95) {
      // Whistles a tune.
      this.mouthOverride = "o";
      this.mouthUntil = n + 1.6;
      this.anim("tilt", [[0.05, 300, Ease.inOut], [-0.05, 500, Ease.inOut], [0, 400, Ease.inOut]]);
      this.emit("note", 3);
    } else {
      // A tiny shiver, as if he heard something.
      this.anim("ox", [[0.03, 40, Ease.out], [-0.03, 60, Ease.inOut], [0.025, 60, Ease.inOut], [-0.015, 60, Ease.inOut], [0, 80, Ease.out]]);
      this.eyeOverride = "dot";
      this.eyeOverrideUntil = n + 0.6;
      this.mouthOverride = "o";
      this.mouthUntil = n + 0.6;
    }
  }

  private doMiniBehaviorLoop() {
    const n = now();
    switch (this.permanentEmote) {
      case "happy":
        if (this.locks.has("oy")) { this.miniNextBehavior = n + 0.4; return; }
        this.anim("oy", [[-0.3, 120, Ease.out], [0.03, 200, Ease.inOut], [0, 160, Ease.back]]);
        this.anim("sy", [[0.82, 80, Ease.out], [1.18, 130, Ease.out], [0.88, 160, Ease.inOut], [1, 200, Ease.back]]);
        this.anim("sx", [[1.15, 80, Ease.out], [0.88, 130, Ease.out], [1.06, 160, Ease.inOut], [1, 200, Ease.back]]);
        this.miniNextBehavior = n + 2.2 + Math.random() * 1.2;
        break;
      case "annoyed":
        if (this.locks.has("yaw")) { this.miniNextBehavior = n + 0.5; return; }
        this.anim("yaw", [
          [-0.65, 50, Ease.out], [0.65, 90, Ease.inOut], [-0.5, 80, Ease.inOut],
          [0.4, 75, Ease.inOut], [-0.2, 70, Ease.inOut], [0, 140, Ease.out],
        ]);
        this.miniNextBehavior = n + 3.0 + Math.random() * 2.5;
        break;
      case "wink":
        this.eyeOverride = "wink";
        this.eyeOverrideUntil = n + 0.55;
        this.anim("tilt", [[0.13, 100, Ease.out], [0.13, 320, Ease.lin], [0, 200, Ease.inOut]]);
        this.miniNextBehavior = n + 2.2 + Math.random() * 2.0;
        break;
      case "love":
        this.emit("heart", 2);
        this.anim("tilt", [[-0.1, 180, Ease.out], [0.1, 340, Ease.inOut], [0, 220, Ease.inOut]]);
        this.miniNextBehavior = n + 2.6 + Math.random() * 1.5;
        break;
      default:
        this.miniNextBehavior = n + 3.0 + Math.random() * 2.0;
    }
  }


  // ── Draw ────────────────────────────────────────────────────────────────────

  /** Draws Bob into a canvas of `W`×`H` CSS pixels (the caller applied the DPR transform). */
  draw(x: CanvasRenderingContext2D, W: number, H: number) {
    const R = W * 0.3;
    this.drawAt(x, W / 2 + this.ox * R, H / 2 + this.particleOverhang / 2 + this.oy * R + R * 0.06, R);
  }

  /** Draws Bob centred on (cx, cy) with body half-size ≈ R. */
  drawAt(x: CanvasRenderingContext2D, cx: number, cy: number, R: number) {
    const m = this.morph;
    const hw = lerp(R * 1.0, R * 1.2, m);
    const hh = lerp(R * 0.96, R * 0.88, m);
    const rad = lerp(R * 0.52, R * 0.3, m);

    // A soft glow around him, in the colour of his mood.
    if (R >= 16) {
      // Kept inside his canvas (half its width is ~1.65 R), so it never shows an edge.
      const gl = x.createRadialGradient(cx, cy, R * 0.5, cx, cy, R * 1.6);
      gl.addColorStop(0, rgba(this.col, 0.2 * (1 - m * 0.6)));
      gl.addColorStop(1, rgba(this.col, 0));
      x.fillStyle = gl;
      x.fillRect(cx - R * 1.7, cy - R * 1.7, R * 3.4, R * 3.4);
    }

    this.drawHands(x, R, hw, hh, cx, cy);

    x.save();
    // He leans a little towards whatever he is looking at.
    x.translate(cx + this.yaw * R * 0.05, cy - this.pitch * R * 0.03);
    const lean = this.tilt + this.yaw * 0.05;
    if (lean !== 0) x.rotate(lean);
    x.scale(this.sx, this.sy);

    if (m < 0.9) this.drawFeet(x, R, hw, hh, 1 - m);

    // The amber twin peeks out behind him (hidden once he turns into the box).
    if (m < 0.9) {
      x.save();
      x.globalAlpha = 1 - m;
      x.translate(R * 0.13, R * 0.12);
      x.rotate(0.05);
      const tw = new Path2D();
      pathRoundRect(tw, -hw * 0.97, -hh * 0.97, hw * 1.94, hh * 1.94, rad);
      const tg = x.createLinearGradient(-hw, -hh, hw, hh);
      tg.addColorStop(0, "#ffdf6b");
      tg.addColorStop(0.55, rgba(AMBER));
      tg.addColorStop(1, rgba(AMBER_DEEP));
      x.fillStyle = tg;
      x.fill(tw);
      x.save();
      x.clip(tw);
      // Gloss on the twin, and the body's shadow falling across it.
      const tgl = x.createRadialGradient(hw * 0.5, -hh * 0.5, 0, hw * 0.5, -hh * 0.5, R * 0.8);
      tgl.addColorStop(0, "rgba(255,255,255,0.4)");
      tgl.addColorStop(1, "rgba(255,255,255,0)");
      x.fillStyle = tgl;
      x.fillRect(-hw, -hh, hw * 2, hh * 2);
      const tsh = x.createLinearGradient(-hw, 0, hw * 0.2, 0);
      tsh.addColorStop(0, "rgba(120,50,0,0.38)");
      tsh.addColorStop(1, "rgba(120,50,0,0)");
      x.fillStyle = tsh;
      x.fillRect(-hw, -hh, hw * 2, hh * 2);
      x.restore();
      x.restore();
    }

    this.drawAntenna(x, R, hh, rad);

    const body = new Path2D();
    pathRoundRect(body, -hw, -hh, hw * 2, hh * 2, rad);
    if (m < 0.9) this.drawArms(x, R, hw, hh, 1 - m);

    // Thickness: a darker copy just below the body, so he is a chunky toy and not a sticker.
    if (R >= 14) {
      x.save();
      x.translate(0, R * 0.08 * (1 - m));
      const ex = x.createLinearGradient(0, 0, 0, hh);
      ex.addColorStop(0, rgba(mix3(TEAL_BOTTOM, [0, 0.12, 0.18], 0.35)));
      ex.addColorStop(1, rgba(mix3(TEAL_BOTTOM, [0, 0.12, 0.18], 0.6)));
      x.fillStyle = ex;
      x.fill(body);
      x.restore();
    }

    this.drawBody(x, body, R, hw, hh);

    // Cheeks: soft, glowing blush.
    const blushVal = Math.max(this.blush, this.tint * 0.25) * (1 - m);
    const cheekA = 0.28 + 0.5 * blushVal;
    x.save();
    x.clip(body);
    const slide = Math.sin(this.yaw) * hw * 0.35;
    for (const sd of [-1, 1]) {
      const bx = sd * hw * 0.64 + slide;
      const by = hh * 0.34;
      const cg = x.createRadialGradient(bx, by, 0, bx, by, R * 0.24);
      cg.addColorStop(0, `rgba(255,105,140,${cheekA})`);
      cg.addColorStop(1, "rgba(255,105,140,0)");
      x.fillStyle = cg;
      x.beginPath();
      x.ellipse(bx, by, R * 0.24, R * 0.16, 0, 0, Math.PI * 2);
      x.fill();
    }
    x.restore();

    this.drawEyes(x, body, R, hw, hh);
    if (m > 0.05) this.drawSlot(x, body, R, hh);
    else this.drawMouth(x, R, hh);
    if (this.look && m < 0.5 && R >= 10) this.drawOutfit(x, R, hw, hh, 1 - m * 2);

    x.restore();

    if (this.badge && this.badgeS > 0.01 && m < 0.25) this.drawBadge(x, this.badge, R, cx, cy);
    this.drawParticles(x, R, cx, cy);
  }

  private drawBody(x: CanvasRenderingContext2D, body: Path2D, R: number, hw: number, hh: number) {
    const tint = this.tint * (1 - this.morph);
    const top = mix3(TEAL_TOP, this.col, tint * 0.4);
    const bottom = mix3(TEAL_BOTTOM, this.col, tint * 0.55);
    const mid = mix3(top, bottom, 0.5);

    // Base, with a soft shadow cast onto the twin behind him.
    const g = x.createLinearGradient(-hw * 0.85, -hh, hw * 0.85, hh);
    g.addColorStop(0, rgba(top));
    g.addColorStop(0.5, rgba(mid));
    g.addColorStop(1, rgba(bottom));
    x.save();
    if (R >= 14) {
      x.shadowColor = "rgba(0,35,45,0.4)";
      x.shadowBlur = R * 0.3;
      x.shadowOffsetX = -R * 0.04;
      x.shadowOffsetY = R * 0.07;
    }
    x.fillStyle = g;
    x.fill(body);
    x.restore();

    x.save();
    x.clip(body);

    // Volume: puffy in the middle, darker towards the edges.
    const puff = x.createRadialGradient(-hw * 0.18, -hh * 0.25, R * 0.1, 0, 0, R * 1.35);
    puff.addColorStop(0, "rgba(255,255,255,0.16)");
    puff.addColorStop(0.55, "rgba(255,255,255,0)");
    puff.addColorStop(1, "rgba(0,55,65,0.32)");
    x.fillStyle = puff;
    x.fillRect(-hw, -hh, hw * 2, hh * 2);

    // Light bouncing up from below, shade in the top-right corner.
    const bounce = x.createRadialGradient(0, hh * 1.05, 0, 0, hh * 1.05, hw * 1.15);
    bounce.addColorStop(0, "rgba(170,255,235,0.42)");
    bounce.addColorStop(1, "rgba(170,255,235,0)");
    x.fillStyle = bounce;
    x.fillRect(-hw, -hh, hw * 2, hh * 2);
    const shade = x.createRadialGradient(hw * 0.95, -hh * 0.95, 0, hw * 0.95, -hh * 0.95, R * 1.1);
    shade.addColorStop(0, "rgba(0,70,80,0.26)");
    shade.addColorStop(1, "rgba(0,70,80,0)");
    x.fillStyle = shade;
    x.fillRect(-hw, -hh, hw * 2, hh * 2);

    // Glossy window-light on the top-left: a soft streak and a bright spot.
    x.save();
    x.translate(-hw * 0.42, -hh * 0.58);
    x.rotate(-0.55);
    const streak = x.createLinearGradient(0, -R * 0.12, 0, R * 0.12);
    streak.addColorStop(0, "rgba(255,255,255,0.0)");
    streak.addColorStop(0.5, "rgba(255,255,255,0.6)");
    streak.addColorStop(1, "rgba(255,255,255,0.0)");
    x.fillStyle = streak;
    x.beginPath();
    x.ellipse(0, 0, R * 0.34, R * 0.1, 0, 0, Math.PI * 2);
    x.fill();
    x.restore();
    x.fillStyle = "rgba(255,255,255,0.75)";
    x.beginPath();
    x.arc(-hw * 0.74, -hh * 0.3, R * 0.045, 0, Math.PI * 2);
    x.fill();
    x.restore();

    if (this.glass) this.drawJelly(x, body, R, hw, hh);

    // Rim light: bright on the lit side, a cool edge on the far side.
    const rim = x.createLinearGradient(-hw, -hh, hw, hh);
    rim.addColorStop(0, "rgba(255,255,255,0.7)");
    rim.addColorStop(0.45, "rgba(255,255,255,0.08)");
    rim.addColorStop(1, "rgba(120,255,235,0.4)");
    x.lineWidth = Math.max(1, R * 0.035);
    x.strokeStyle = rim;
    x.stroke(body);
  }

  /** Liquid Glass: light passing through him. A wide liquid highlight across the top,
   *  a bright caustic where the light gathers at the bottom, a fine inner edge. */
  private drawJelly(x: CanvasRenderingContext2D, body: Path2D, R: number, hw: number, hh: number) {
    x.save();
    x.clip(body);
    // The top of the jelly: a curved band of reflected sky.
    const band = new Path2D();
    band.moveTo(-hw * 1.1, -hh * 1.1);
    band.lineTo(hw * 1.1, -hh * 1.1);
    band.lineTo(hw * 1.1, -hh * 0.42);
    band.quadraticCurveTo(0, -hh * 0.08, -hw * 1.1, -hh * 0.36);
    band.closePath();
    const bg = x.createLinearGradient(0, -hh, 0, -hh * 0.2);
    bg.addColorStop(0, "rgba(255,255,255,0.42)");
    bg.addColorStop(1, "rgba(255,255,255,0.04)");
    x.fillStyle = bg;
    x.fill(band);
    // The caustic: light focused through the body onto its lower edge.
    const cg = x.createRadialGradient(hw * 0.15, hh * 0.98, 0, hw * 0.15, hh * 0.98, hw * 0.95);
    cg.addColorStop(0, "rgba(220,255,248,0.55)");
    cg.addColorStop(0.45, "rgba(200,255,245,0.16)");
    cg.addColorStop(1, "rgba(200,255,245,0)");
    x.fillStyle = cg;
    x.fillRect(-hw, -hh, hw * 2, hh * 2);
    // A faint rainbow where the edge bends the light.
    const ir = x.createLinearGradient(-hw, hh, hw, -hh);
    ir.addColorStop(0, "rgba(255,140,200,0.0)");
    ir.addColorStop(0.35, "rgba(255,160,210,0.16)");
    ir.addColorStop(0.55, "rgba(140,200,255,0.16)");
    ir.addColorStop(0.8, "rgba(140,255,220,0.0)");
    x.lineWidth = Math.max(1.5, R * 0.12);
    x.strokeStyle = ir;
    x.stroke(body);
    x.restore();
    // A fine bright inner edge, so he reads as glass.
    x.save();
    x.clip(body);
    x.lineWidth = Math.max(1, R * 0.05);
    x.strokeStyle = "rgba(255,255,255,0.35)";
    x.stroke(body);
    x.restore();
  }

  /** Little arms that swing with him; hidden while the amber hands wave. */
  private drawArms(x: CanvasRenderingContext2D, R: number, hw: number, hh: number, a: number) {
    const k = a * (1 - Math.min(1, this.hands * 3));
    if (R < 14 || k < 0.05) return;
    const t = now();
    x.save();
    x.globalAlpha = k;
    for (const sd of [-1, 1]) {
      const swing = Math.sin(t * 1.7 + (sd > 0 ? 0.6 : 0)) * 0.05 + this.tilt * -1.4 + this.antV * 0.002 * sd + Math.max(0, -this.oy) * 1.8 * sd;
      x.save();
      x.translate(sd * hw * 0.96, hh * 0.22);
      x.rotate(sd * (0.42 + swing));
      const g = x.createLinearGradient(-R * 0.18, 0, R * 0.18, 0);
      g.addColorStop(0, rgba(mix3(TEAL_TOP, TEAL_BOTTOM, 0.35)));
      g.addColorStop(1, rgba(mix3(TEAL_BOTTOM, [0, 0.12, 0.18], 0.3)));
      x.fillStyle = g;
      x.beginPath();
      x.ellipse(0, R * 0.16, R * 0.17, R * 0.27, 0, 0, Math.PI * 2);
      x.fill();
      x.restore();
    }
    x.restore();
  }

  /** Two stubby feet, so he stands instead of floating. */
  private drawFeet(x: CanvasRenderingContext2D, R: number, hw: number, hh: number, a: number) {
    if (R < 12 || a < 0.05) return;
    x.save();
    x.globalAlpha = a;
    const g = x.createLinearGradient(0, hh * 0.9, 0, hh * 1.25);
    g.addColorStop(0, rgba(mix3(TEAL_BOTTOM, [0, 0.1, 0.15], 0.25)));
    g.addColorStop(1, rgba(mix3(TEAL_BOTTOM, [0, 0.1, 0.15], 0.55)));
    x.fillStyle = g;
    const lift = Math.max(0, -this.oy) * R * 0.5; // feet tuck up a little in a hop
    for (const sd of [-1, 1]) {
      x.beginPath();
      x.ellipse(sd * hw * 0.42, hh * 1.02 - lift * 0.3, R * 0.27, R * 0.15, 0, 0, Math.PI * 2);
      x.fill();
    }
    x.restore();
  }

  /** Antenna: a short stalk and a bulb that glows in the state's colour. */
  private drawAntenna(x: CanvasRenderingContext2D, R: number, hh: number, rad: number) {
    const a = 1 - this.morph;
    if (a < 0.05 || R < 12) return;
    const t = now();
    const sway = Math.sin(t * 2.2) * 0.04 + this.antA;
    const len = R * 0.34 * this.antS;
    const topY = -hh + rad * 0.12;
    const bx = Math.sin(sway) * len;
    const by = topY - Math.cos(sway) * len;

    x.save();
    x.globalAlpha = a;
    x.strokeStyle = rgba(mix3(TEAL_BOTTOM, [0, 0.15, 0.2], 0.35));
    x.lineWidth = Math.max(1.5, R * 0.06);
    x.lineCap = "round";
    x.beginPath();
    x.moveTo(0, topY + R * 0.04);
    x.quadraticCurveTo(bx * 0.2, topY - len * 0.6, bx, by);
    x.stroke();

    const pulse = this.cfg.bounces || this.cfg.sweat ? 0.5 + 0.5 * Math.sin(t * 6) : 0.5 + 0.5 * Math.sin(t * 2);
    const br = R * 0.11;
    this.bulbAt = { x: bx, y: by, r: br };
    const glow = x.createRadialGradient(bx, by, 0, bx, by, br * (2.6 + pulse));
    glow.addColorStop(0, rgba(this.col, 0.55));
    glow.addColorStop(1, rgba(this.col, 0));
    x.fillStyle = glow;
    x.beginPath();
    x.arc(bx, by, br * (2.6 + pulse), 0, Math.PI * 2);
    x.fill();
    const bg = x.createRadialGradient(bx - br * 0.3, by - br * 0.35, 0, bx, by, br * 1.1);
    bg.addColorStop(0, rgba(mix3(this.col, [1, 1, 1], 0.85)));
    bg.addColorStop(0.5, rgba(this.col));
    bg.addColorStop(1, rgba(mix3(this.col, [0, 0.1, 0.15], 0.35)));
    x.fillStyle = bg;
    x.beginPath();
    x.arc(bx, by, br, 0, Math.PI * 2);
    x.fill();
    x.lineWidth = Math.max(1, br * 0.2);
    x.strokeStyle = "rgba(255,255,255,0.45)";
    x.stroke();
    x.fillStyle = "rgba(255,255,255,0.85)";
    x.beginPath();
    x.ellipse(bx - br * 0.32, by - br * 0.38, br * 0.28, br * 0.18, -0.6, 0, Math.PI * 2);
    x.fill();
    x.restore();
  }

  private drawEyes(x: CanvasRenderingContext2D, body: Path2D, R: number, hw: number, hh: number) {
    let shape: EyeShape = this.eyeOverride ?? this.cfg.eye;
    if (this.morph > 0.5) {
      if (this.isChewing) shape = "happy";
      else if (this.slotHTarget > 0.05 || this.slotH > 0.1) shape = "cup";
    }
    x.save();
    x.clip(body);
    x.fillStyle = INK;
    x.strokeStyle = INK;
    const lift = this.morph * hh * 0.1;
    for (const sd of [-1, 1]) {
      const ex = sd * hw * 0.34 + this.yaw * hw * 0.46 + this.sacX * hw * 0.25 + Math.sin(this.roll) * hw * 0.2;
      const ey = hh * 0.06 - this.pitch * hh * 0.5 + this.sacY * hh * 0.2 + lift;
      // Eyes squeeze a little as they look sideways, like they sit on a curved face.
      const fx = 1 - Math.min(0.28, Math.abs(this.yaw) * 0.35);
      x.fillStyle = INK;
      x.save();
      x.translate(ex, ey);
      x.scale(fx, 1);
      this.drawEyeShape(x, shape, R * 0.25 * this.es, R * 0.34 * this.es, sd);
      x.restore();

      // Eyebrows: this is most of what makes him look alive.
      const bo = this.brow[4];
      if (bo > 0.02) {
        const by = sd < 0 ? this.brow[0] : this.brow[2];
        const br = sd < 0 ? this.brow[1] : this.brow[3];
        x.save();
        x.globalAlpha = bo;
        x.translate(ex, ey - R * 0.4 * this.es - by * R);
        x.rotate(br);
        x.strokeStyle = "rgba(10,28,34,0.9)";
        x.lineWidth = Math.max(1.4, R * 0.07);
        x.lineCap = "round";
        x.beginPath();
        x.moveTo(-R * 0.15, R * 0.02);
        x.quadraticCurveTo(0, -R * 0.06, R * 0.15, R * 0.02);
        x.stroke();
        x.restore();
      }
    }
    x.restore();
  }

  private drawEyeShape(x: CanvasRenderingContext2D, shape: EyeShape, w: number, h: number, sd: number) {
    const t = now();
    const arc = (up: boolean) => {
      x.lineWidth = w * 0.42;
      x.lineCap = "round";
      x.beginPath();
      if (up) x.arc(0, h * 0.22, w * 0.78, Math.PI * 1.1, Math.PI * 1.9);
      else x.arc(0, -h * 0.12, w * 0.78, Math.PI * 0.1, Math.PI * 0.9);
      x.stroke();
    };
    const glossy = (ew: number, eh: number) => {
      const hh = Math.max(eh * this.open, ew * 0.35);
      // Deep navy, a little lighter towards the bottom like a glass bead.
      const eg = x.createLinearGradient(0, -hh, 0, hh);
      eg.addColorStop(0, "#06121b");
      eg.addColorStop(0.6, "#0d2b3a");
      eg.addColorStop(1, "#14495a");
      x.fillStyle = eg;
      x.beginPath();
      x.ellipse(0, 0, ew, hh, 0, 0, Math.PI * 2);
      x.fill();
      if (hh > ew * 0.7) {
        x.save();
        x.beginPath();
        x.ellipse(0, 0, ew, hh, 0, 0, Math.PI * 2);
        x.clip();
        // Teal light reflected in the lower part of the eye.
        const rg = x.createRadialGradient(0, hh * 0.85, 0, 0, hh * 0.85, ew * 1.25);
        rg.addColorStop(0, "rgba(94,234,212,0.6)");
        rg.addColorStop(1, "rgba(94,234,212,0)");
        x.fillStyle = rg;
        x.fillRect(-ew, -hh, ew * 2, hh * 2);
        x.restore();
        x.fillStyle = "rgba(255,255,255,0.96)";
        x.beginPath();
        x.ellipse(-ew * 0.3, -hh * 0.38, ew * 0.36, ew * 0.4, -0.4, 0, Math.PI * 2);
        x.fill();
        x.fillStyle = "rgba(255,255,255,0.7)";
        x.beginPath();
        x.arc(ew * 0.36, hh * 0.32, ew * 0.16, 0, Math.PI * 2);
        x.fill();
        x.fillStyle = INK;
      }
    };
    switch (shape) {
      case "pill":
        glossy(w * 0.8, h * 0.86);
        break;
      case "wide":
        glossy(w * 0.92, h * 1.0);
        break;
      case "dot":
        glossy(w * 0.62, w * 0.62);
        break;
      case "line":
        x.rotate(-sd * 0.22);
        roundRectPath(x, -w * 0.8, -w * 0.18, w * 1.6, w * 0.36, w * 0.18);
        x.fill();
        break;
      case "flat":
        x.rotate(sd * 0.16);
        roundRectPath(x, -w * 0.78, -w * 0.17, w * 1.56, w * 0.34, w * 0.17);
        x.fill();
        break;
      case "happy":
        arc(true);
        break;
      case "closed":
        arc(false);
        break;
      case "spiral": {
        x.lineWidth = w * 0.22;
        x.lineCap = "round";
        x.beginPath();
        for (let a = 0; a < 4.4 * Math.PI; a += 0.2) {
          const r = w * 0.06 + a * w * 0.058;
          const aa = a + t * 9 * sd;
          const px = Math.cos(aa) * r;
          const py = Math.sin(aa) * r;
          if (a === 0) x.moveTo(px, py);
          else x.lineTo(px, py);
        }
        x.stroke();
        break;
      }
      case "heart":
        x.fillStyle = "#FF4D6D";
        heartPath(x, w * 1.15);
        x.fill();
        x.fillStyle = INK;
        break;
      case "star":
        x.fillStyle = "#FFC933";
        x.rotate(t * 1.5 * sd);
        starPath(x, w * 1.05, w * 0.46);
        x.fill();
        x.fillStyle = INK;
        break;
      case "tired": {
        // Heavy-lidded: only the lower half of the eye shows, under a flat lid line.
        x.beginPath();
        x.ellipse(0, 0, w * 0.62, h * 0.62, 0, 0, Math.PI);
        x.closePath();
        x.fill();
        break;
      }
      case "wink":
        if (sd < 0) glossy(w * 0.62, h * 0.9);
        else arc(true);
        break;
      case "cup": {
        const hh = Math.max(h * this.open * 0.9, w * 0.35);
        x.beginPath();
        x.ellipse(0, 0, w * 0.62, hh, 0, 0, Math.PI * 2);
        x.fill();
        break;
      }
    }
  }

  /** Mouth for the normal (cube) body. */
  private drawMouth(x: CanvasRenderingContext2D, R: number, hh: number) {
    let shape: MouthShape = this.cfg.mouth;
    const eye = this.eyeOverride;
    const forced = this.mouthOverride;
    if (eye === "happy" || eye === "heart" || eye === "star") shape = "grin";
    else if (eye === "dot") shape = "o";
    else if (eye === "line") shape = "flat";
    else if (eye === "tired" || eye === "closed") shape = "tiny";
    else if (eye === "wink") shape = "smile";
    if (forced) shape = forced;

    const y = hh * 0.47 - this.pitch * hh * 0.12;
    const mx = this.yaw * R * 0.34;
    x.save();
    x.translate(mx, y);
    x.strokeStyle = INK;
    x.fillStyle = INK;
    x.lineCap = "round";
    x.lineJoin = "round";
    x.lineWidth = Math.max(1.4, R * 0.07);
    const w = R * 0.26;
    switch (shape) {
      case "smile":
        x.beginPath();
        x.moveTo(-w, 0);
        x.quadraticCurveTo(0, R * 0.2, w, 0);
        x.stroke();
        break;
      case "grin":
        x.beginPath();
        x.moveTo(-w * 1.15, -R * 0.02);
        x.quadraticCurveTo(0, R * 0.32, w * 1.15, -R * 0.02);
        x.closePath();
        x.fill();
        x.fillStyle = "rgba(255,120,140,0.9)";
        x.beginPath();
        x.ellipse(0, R * 0.12, w * 0.5, R * 0.06, 0, 0, Math.PI * 2);
        x.fill();
        break;
      case "flat":
        x.beginPath();
        x.moveTo(-w * 0.8, R * 0.04);
        x.lineTo(w * 0.8, R * 0.04);
        x.stroke();
        break;
      case "o":
        x.beginPath();
        x.ellipse(0, R * 0.05, R * 0.09, R * 0.12, 0, 0, Math.PI * 2);
        x.fill();
        break;
      case "wavy": {
        x.beginPath();
        const t = now();
        for (let i = 0; i <= 12; i++) {
          const u = i / 12;
          const px = -w + u * w * 2;
          const py = Math.sin(u * Math.PI * 3 + t * 6) * R * 0.04;
          if (i === 0) x.moveTo(px, py);
          else x.lineTo(px, py);
        }
        x.stroke();
        break;
      }
      case "tiny":
        x.beginPath();
        x.moveTo(-w * 0.4, 0);
        x.quadraticCurveTo(0, R * 0.07, w * 0.4, 0);
        x.stroke();
        break;
      case "hmm":
        x.beginPath();
        x.moveTo(-w * 0.8, R * 0.05);
        x.quadraticCurveTo(-w * 0.1, -R * 0.02, w * 0.8, R * 0.06);
        x.stroke();
        break;
    }
    x.restore();
  }

  /** The cube's big "eating" mouth: a dark slot with an amber rim, used for drops. */
  private drawSlot(x: CanvasRenderingContext2D, body: Path2D, R: number, hh: number) {
    const m = this.morph;
    const w = R * 1.55 * m;
    const h = Math.max(R * 0.1, this.slotH * R * 1.1) * m;
    const y = hh * 0.2;
    x.save();
    x.clip(body);
    const r = Math.min(w / 2, h / 2);
    roundRectPath(x, -w / 2, y, w, h, r);
    const g = x.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, "rgb(6,18,22)");
    g.addColorStop(1, "rgb(14,40,46)");
    x.fillStyle = g;
    x.fill();
    x.lineWidth = Math.max(1.2, R * 0.05);
    x.strokeStyle = `rgba(251,191,36,${0.9 * m})`;
    x.stroke();
    x.restore();
  }

  /** Little round hands, in the amber of the twin; they wave during the greeting. */
  private drawHands(x: CanvasRenderingContext2D, R: number, hw: number, hh: number, cx: number, cy: number) {
    if (this.hands <= 0.01 || R <= 14) return;
    const n = now();
    const r = R * 0.2 * this.hands;
    const waving = this.waveStart > 0 && n >= this.waveStart && n < this.waveUntil;
    const cosT = Math.cos(this.tilt);
    const sinT = Math.sin(this.tilt);
    for (const sd of [-1, 1]) {
      let lx = sd * hw * this.sx * 1.04;
      let ly = hh * this.sy * 0.45;
      if (sd > 0 && waving) {
        const wt = n - this.waveStart;
        const rise = 1 - Math.pow(1 - Math.min(1, wt / 0.18), 3);
        lx += (hw * 0.18 + Math.cos(13 * wt) * R * 0.1) * rise;
        ly += (-hh * 1.15 + Math.sin(13 * wt) * R * 0.2) * rise;
      }
      const wx = cx + cosT * lx - sinT * ly;
      const wy = cy + sinT * lx + cosT * ly;
      const g = x.createRadialGradient(wx - r * 0.3, wy - r * 0.3, 0, wx, wy, r * 1.1);
      g.addColorStop(0, rgba(mix3(AMBER, [1, 1, 1], 0.4)));
      g.addColorStop(1, rgba(AMBER_DEEP));
      x.beginPath();
      x.arc(wx, wy, r, 0, Math.PI * 2);
      x.fillStyle = g;
      x.fill();
    }
  }

  private drawBadge(x: CanvasRenderingContext2D, badge: Badge, R: number, cx: number, cy: number) {
    const bs = this.badgeS;
    const bx = cx - R * 0.78 * this.sx;
    const by = cy - R * 0.78 * this.sy;
    const t = now();
    x.save();
    x.translate(bx, by);
    x.scale(bs, bs);
    const col = rgba(badge.color);
    if (badge.kind === "dots") {
      const pw = R * 0.74;
      const ph = R * 0.38;
      roundRectPath(x, -pw / 2, -ph / 2, pw, ph, ph * 0.38);
      x.fillStyle = col;
      x.fill();
      for (let i = 0; i < 3; i++) {
        const phase = (((t * 2.4 - i * 0.22) % 1) + 1) % 1;
        const dotR = R * 0.055 * (1 + 0.4 * Math.max(0, Math.sin(phase * Math.PI * 2)));
        x.fillStyle = "#fff";
        x.beginPath();
        x.arc((i - 1) * R * 0.18, 0, dotR, 0, Math.PI * 2);
        x.fill();
      }
    } else if (badge.kind === "bang" || badge.kind === "question") {
      const s = R * 0.5;
      roundRectPath(x, -s / 2, -s / 2, s, s, s * 0.34);
      x.fillStyle = col;
      x.fill();
      x.fillStyle = "#fff";
      x.font = `900 ${R * 0.32}px ${FONT}`;
      x.textAlign = "center";
      x.textBaseline = "middle";
      x.fillText(badge.kind === "bang" ? "!" : "?", 0, R * 0.02);
    } else {
      x.fillStyle = "#06141a";
      x.beginPath();
      x.arc(0, 0, R * 0.2, 0, Math.PI * 2);
      x.fill();
      x.fillStyle = col;
      x.beginPath();
      x.arc(0, 0, R * 0.135, 0, Math.PI * 2);
      x.fill();
    }
    x.restore();
  }

  // ── Outfits ────────────────────────────────────────────────────────────────
  // Drawn in his own (leaning, squashing) frame, after the face.

  private drawOutfit(x: CanvasRenderingContext2D, R: number, hw: number, hh: number, a: number) {
    const L = this.look!;
    x.save();
    x.globalAlpha *= a;
    if (L.scarf) this.drawScarf(x, R, hw, hh, L.special === "christmas");
    if (L.glasses) this.drawGlasses(x, R, hw, hh);
    if (L.egg) this.drawEgg(x, R, hw, hh);
    if (L.hat !== "none") this.drawHat(x, R, hw, hh, L.hat);
    if (L.flower) this.drawFlower(x);
    x.restore();
  }

  private drawScarf(x: CanvasRenderingContext2D, R: number, hw: number, hh: number, festive: boolean) {
    const top = hh * 0.66, h = R * 0.24;
    const c1 = festive ? "#e8384f" : "#e86a4f", c2 = festive ? "#fdf6ec" : "#f6b24a";
    x.save();
    // The wrap around him, slightly wider than his body.
    const band = new Path2D();
    band.moveTo(-hw * 1.05, top);
    band.quadraticCurveTo(0, top + h * 0.35, hw * 1.05, top);
    band.lineTo(hw * 1.03, top + h);
    band.quadraticCurveTo(0, top + h * 1.45, -hw * 1.03, top + h);
    band.closePath();
    const g = x.createLinearGradient(0, top, 0, top + h * 1.3);
    g.addColorStop(0, c1);
    g.addColorStop(1, shade(c1, -0.25));
    x.fillStyle = g;
    x.fill(band);
    // Knitted stripes.
    x.save();
    x.clip(band);
    x.fillStyle = c2;
    for (let i = -6; i <= 6; i += 2) {
      x.globalAlpha = 0.8;
      x.fillRect(i * hw * 0.18, top - h, hw * 0.13, h * 3);
    }
    x.restore();
    // The tail hanging down on his right, swaying a little.
    const sw = Math.sin(now() * 1.6) * R * 0.03;
    const tail = new Path2D();
    tail.moveTo(hw * 0.45, top + h * 0.7);
    tail.lineTo(hw * 0.78, top + h * 0.75);
    tail.lineTo(hw * 0.74 + sw, top + h * 2.5);
    tail.lineTo(hw * 0.44 + sw, top + h * 2.4);
    tail.closePath();
    x.fillStyle = shade(c1, -0.1);
    x.fill(tail);
    x.save();
    x.clip(tail);
    x.fillStyle = c2;
    for (let k = 0; k < 3; k++) x.fillRect(hw * 0.4, top + h * (1.1 + k * 0.5), hw * 0.5, h * 0.2);
    x.restore();
    // Fringe.
    x.strokeStyle = shade(c1, -0.2);
    x.lineWidth = Math.max(1, R * 0.03);
    for (let k = 0; k < 4; k++) {
      const fx = hw * (0.47 + k * 0.09) + sw;
      x.beginPath();
      x.moveTo(fx, top + h * 2.45);
      x.lineTo(fx, top + h * 2.75);
      x.stroke();
    }
    x.restore();
  }

  private drawGlasses(x: CanvasRenderingContext2D, R: number, hw: number, hh: number) {
    x.save();
    const ey = hh * 0.06 - this.pitch * hh * 0.5;
    const centers = [-1, 1].map((sd) => sd * hw * 0.34 + this.yaw * hw * 0.46);
    const lw = R * 0.36, lh = R * 0.3;
    x.lineWidth = Math.max(1.2, R * 0.05);
    x.strokeStyle = "rgba(10,20,26,0.95)";
    for (const cx of centers) {
      const lens = new Path2D();
      pathRoundRect(lens, cx - lw / 2, ey - lh / 2, lw, lh, lh * 0.45);
      const g = x.createLinearGradient(cx, ey - lh / 2, cx, ey + lh / 2);
      g.addColorStop(0, "rgba(20,40,60,0.72)");
      g.addColorStop(1, "rgba(60,30,80,0.62)");
      x.fillStyle = g;
      x.fill(lens);
      x.stroke(lens);
      // A sunny glint.
      x.fillStyle = "rgba(255,255,255,0.55)";
      x.beginPath();
      x.ellipse(cx - lw * 0.18, ey - lh * 0.18, lw * 0.14, lh * 0.08, -0.5, 0, Math.PI * 2);
      x.fill();
    }
    // Bridge.
    x.beginPath();
    x.moveTo(centers[0] + lw / 2, ey - lh * 0.1);
    x.quadraticCurveTo((centers[0] + centers[1]) / 2, ey - lh * 0.35, centers[1] - lw / 2, ey - lh * 0.1);
    x.stroke();
    x.restore();
  }

  private drawHat(x: CanvasRenderingContext2D, R: number, hw: number, hh: number, hat: Look["hat"]) {
    x.save();
    const top = -hh;
    if (hat === "beanie") {
      const c = this.look?.season === "winter" ? "#4f7bd9" : "#d9822b";
      const dome = new Path2D();
      dome.moveTo(-hw * 0.92, top + R * 0.22);
      dome.bezierCurveTo(-hw * 0.9, top - R * 0.62, hw * 0.9, top - R * 0.62, hw * 0.92, top + R * 0.22);
      dome.closePath();
      const g = x.createRadialGradient(-hw * 0.3, top - R * 0.3, R * 0.05, 0, top, R * 1.1);
      g.addColorStop(0, shade(c, 0.25));
      g.addColorStop(1, shade(c, -0.2));
      x.fillStyle = g;
      x.fill(dome);
      // Knit lines.
      x.save();
      x.clip(dome);
      x.strokeStyle = shade(c, -0.3);
      x.globalAlpha = 0.35;
      x.lineWidth = Math.max(1, R * 0.03);
      for (let i = -4; i <= 4; i++) {
        x.beginPath();
        x.moveTo(i * hw * 0.22, top + R * 0.3);
        x.lineTo(i * hw * 0.16, top - R * 0.6);
        x.stroke();
      }
      x.restore();
      // Folded rim.
      const rim = new Path2D();
      pathRoundRect(rim, -hw * 0.98, top + R * 0.06, hw * 1.96, R * 0.24, R * 0.1);
      x.fillStyle = shade(c, -0.08);
      x.fill(rim);
      x.save();
      x.clip(rim);
      x.fillStyle = shade(c, 0.12);
      for (let i = -10; i <= 10; i += 2) x.fillRect(i * hw * 0.1, top, hw * 0.06, R * 0.5);
      x.restore();
      // Pom-pom, off to one side so his antenna pokes out.
      this.pompom(x, -hw * 0.55, top - R * 0.36, R * 0.15, "#fff7ec");
    } else if (hat === "santa") {
      const tilt = 0.32;
      x.translate(hw * 0.12, top + R * 0.12);
      x.rotate(tilt);
      const cone = new Path2D();
      cone.moveTo(-hw * 0.82, 0);
      cone.quadraticCurveTo(-hw * 0.1, -R * 1.25, hw * 0.75, -R * 0.75);
      cone.lineTo(hw * 0.78, 0);
      cone.closePath();
      const g = x.createLinearGradient(-hw, -R, hw, 0);
      g.addColorStop(0, "#ff5a5f");
      g.addColorStop(1, "#c81e35");
      x.fillStyle = g;
      x.fill(cone);
      const fur = new Path2D();
      pathRoundRect(fur, -hw * 0.95, -R * 0.06, hw * 1.85, R * 0.26, R * 0.13);
      x.fillStyle = "#fffaf3";
      x.fill(fur);
      this.pompom(x, hw * 0.78, -R * 0.78, R * 0.16, "#fffaf3");
    } else if (hat === "party") {
      x.translate(-hw * 0.38, top + R * 0.08);
      x.rotate(-0.22);
      const cone = new Path2D();
      cone.moveTo(-R * 0.36, 0);
      cone.lineTo(0, -R * 0.9);
      cone.lineTo(R * 0.36, 0);
      cone.closePath();
      x.fillStyle = "#7c5cff";
      x.fill(cone);
      x.save();
      x.clip(cone);
      x.fillStyle = "#ffd23f";
      for (let i = 0; i < 5; i++) {
        x.save();
        x.translate(0, -R * 0.18 * i);
        x.rotate(-0.5);
        x.fillRect(-R * 0.6, -R * 0.04, R * 1.2, R * 0.07);
        x.restore();
      }
      x.restore();
      this.pompom(x, 0, -R * 0.92, R * 0.1, "#ff6b9a");
    } else if (hat === "pumpkin") {
      x.translate(-hw * 0.32, top + R * 0.04);
      const pr = R * 0.36;
      for (const k of [-1, 0, 1]) {
        x.beginPath();
        x.ellipse(k * pr * 0.45, -pr * 0.55, pr * 0.55, pr * 0.62, 0, 0, Math.PI * 2);
        const g = x.createRadialGradient(k * pr * 0.45 - pr * 0.15, -pr * 0.75, pr * 0.05, k * pr * 0.45, -pr * 0.55, pr * 0.7);
        g.addColorStop(0, "#ffb14a");
        g.addColorStop(1, "#e2690f");
        x.fillStyle = g;
        x.fill();
      }
      x.fillStyle = "#3f7d2b";
      x.beginPath();
      x.ellipse(0, -pr * 1.18, pr * 0.1, pr * 0.22, 0.3, 0, Math.PI * 2);
      x.fill();
    }
    x.restore();
  }

  private pompom(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, c: string) {
    const g = x.createRadialGradient(cx - r * 0.35, cy - r * 0.35, r * 0.1, cx, cy, r);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(1, shade(c, -0.12));
    x.fillStyle = g;
    x.beginPath();
    x.arc(cx, cy, r, 0, Math.PI * 2);
    x.fill();
  }

  /** A little flower on his antenna. */
  private drawFlower(x: CanvasRenderingContext2D) {
    const { x: bx, y: by, r } = this.bulbAt;
    if (r <= 0) return;
    x.save();
    x.translate(bx, by);
    x.rotate(now() * 0.25);
    for (let i = 0; i < 6; i++) {
      x.save();
      x.rotate((i * Math.PI) / 3);
      x.fillStyle = i % 2 ? "#ff9ec4" : "#ffc2dc";
      x.beginPath();
      x.ellipse(0, -r * 1.25, r * 0.62, r * 0.9, 0, 0, Math.PI * 2);
      x.fill();
      x.restore();
    }
    x.restore();
  }

  /** A red egg for (Greek) Easter, held by his side. */
  private drawEgg(x: CanvasRenderingContext2D, R: number, hw: number, hh: number) {
    x.save();
    x.translate(hw * 1.12, hh * 0.55);
    x.rotate(0.25);
    const g = x.createRadialGradient(-R * 0.06, -R * 0.08, R * 0.02, 0, 0, R * 0.26);
    g.addColorStop(0, "#ff6b6b");
    g.addColorStop(1, "#b3121f");
    x.fillStyle = g;
    x.beginPath();
    x.ellipse(0, 0, R * 0.17, R * 0.22, 0, 0, Math.PI * 2);
    x.fill();
    x.fillStyle = "rgba(255,255,255,0.5)";
    x.beginPath();
    x.ellipse(-R * 0.05, -R * 0.08, R * 0.04, R * 0.06, -0.4, 0, Math.PI * 2);
    x.fill();
    x.restore();
  }

  private drawParticles(x: CanvasRenderingContext2D, R: number, cx: number, cy: number) {
    for (const p of this.particles) {
      if (p.age <= 0) continue;
      const k = p.age / p.life;
      const a = k < 0.2 ? k / 0.2 : 1 - (k - 0.2) / 0.8;
      const px = cx + (p.x + p.vx * p.age) * R * 1.3;
      const py = cy + (p.y + p.vy * p.age) * R * 1.3;
      const sz = R * p.size * (1 + k * 0.4);
      x.save();
      x.translate(px, py);
      x.globalAlpha = Math.min(1, Math.max(0, a));
      switch (p.type) {
        case "heart":
          x.rotate(Math.sin(p.age * 6) * 0.3);
          x.fillStyle = "#FF4D6D";
          heartPath(x, sz);
          x.fill();
          break;
        case "star":
          x.rotate(p.rot + p.age * 2);
          x.fillStyle = "#FFC933";
          starPath(x, sz, sz * 0.45);
          x.fill();
          break;
        case "spark":
          x.rotate(p.rot);
          x.fillStyle = "#fff";
          starPath(x, sz * 0.8, sz * 0.18);
          x.fill();
          break;
        case "sweat":
          x.fillStyle = "#7CC7FF";
          x.beginPath();
          x.moveTo(0, -sz);
          x.quadraticCurveTo(sz * 0.8, sz * 0.2, 0, sz * 0.6);
          x.quadraticCurveTo(-sz * 0.8, sz * 0.2, 0, -sz);
          x.fill();
          break;
        case "note":
          x.rotate(Math.sin(p.age * 5) * 0.25);
          x.fillStyle = p.rot > 3 ? "#FBBF24" : "#5EEAD4";
          x.font = `700 ${sz * 2.4}px ${FONT}`;
          x.textAlign = "center";
          x.textBaseline = "middle";
          x.fillText("♪", 0, 0);
          break;
        case "z":
          x.fillStyle = "rgb(190,235,230)";
          x.font = `700 ${sz * 1.9}px ${FONT}`;
          x.textAlign = "center";
          x.textBaseline = "middle";
          x.fillText("z", 0, 0);
          break;
      }
      x.restore();
    }
  }
}

function pathRoundRect(p: Path2D, X: number, Y: number, W: number, H: number, R: number) {
  const r = Math.max(0, Math.min(R, W / 2, H / 2));
  p.moveTo(X + r, Y);
  p.arcTo(X + W, Y, X + W, Y + H, r);
  p.arcTo(X + W, Y + H, X, Y + H, r);
  p.arcTo(X, Y + H, X, Y, r);
  p.arcTo(X, Y, X + W, Y, r);
  p.closePath();
}
