//! Dragging a window across the edge, like a second monitor: the window hangs over the
//! edge while you drag, and the other computer shows the part that is past it. Let go
//! more than halfway over and the program moves there (see "move apps").
//!
//! The window only runs on one computer, so the other one shows a live picture of it:
//! JPEG frames a few times a second, plus where it is on every mouse move. This file is
//! the platform-independent part: the geometry, the pictures and the pointer drawn on
//! them. It is pure, so it is tested on every machine.

use crate::platform::{Screen, SpanView};
use crate::proto::Edge;

/// Largest picture sent (it is shown at full size on the other side, just softer).
pub const FRAME_MAX_W: u32 = 1280;
pub const FRAME_MAX_H: u32 = 900;
pub const FRAME_QUALITY: u8 = 62;
/// How often a picture is taken while the window hangs across.
pub const FRAME_EVERY_MS: u64 = 90;

/// A window hanging across `edge` of `scr`: its size and where the pointer holds it.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Geo {
    pub edge: Edge,
    pub scr: Screen,
    pub w: i32,
    pub h: i32,
    /// The pointer, inside the window.
    pub gx: i32,
    pub gy: i32,
}

impl Geo {
    fn horizontal(&self) -> bool {
        matches!(self.edge, Edge::Left | Edge::Right)
    }

    /// The window's size across the edge.
    fn depth(&self) -> i32 {
        if self.horizontal() {
            self.w
        } else {
            self.h
        }
    }

    /// Keeps the (virtual) pointer on this screen, except across the edge, where the
    /// window may go until it is entirely on the other side.
    pub fn clamp(&self, vx: i32, vy: i32) -> (i32, i32) {
        self.clamp_room(vx, vy, 0)
    }

    /// Like `clamp`, but the pointer may also go up to `room` pixels past the edge (the
    /// other computer's screen, in this one's pixels): once the window is entirely over,
    /// it carries on across that screen instead of getting stuck at the edge.
    pub fn clamp_room(&self, vx: i32, vy: i32, room: i32) -> (i32, i32) {
        let s = self.scr;
        let (right, bottom) = (s.x + s.width, s.y + s.height);
        let cx = |lo: i32, hi: i32, v: i32| v.max(lo).min(hi.max(lo));
        let room = room.max(0);
        match self.edge {
            Edge::Right => (
                cx(s.x, right + self.gx.max(room), vx),
                cx(s.y, bottom - 1, vy),
            ),
            Edge::Left => (
                cx(s.x - (self.w - self.gx).max(room), right - 1, vx),
                cx(s.y, bottom - 1, vy),
            ),
            Edge::Bottom => (
                cx(s.x, right - 1, vx),
                cx(s.y, bottom + self.gy.max(room), vy),
            ),
            Edge::Top => (
                cx(s.x, right - 1, vx),
                cx(s.y - (self.h - self.gy).max(room), bottom - 1, vy),
            ),
            _ => (cx(s.x, right - 1, vx), cx(s.y, bottom - 1, vy)),
        }
    }

    /// How many pixels of the window are past the edge (negative: still that far inside).
    pub fn crossed(&self, vx: i32, vy: i32) -> i32 {
        let s = self.scr;
        let (left, top) = (vx - self.gx, vy - self.gy);
        match self.edge {
            Edge::Right => left + self.w - (s.x + s.width),
            Edge::Left => s.x - left,
            Edge::Bottom => top + self.h - (s.y + s.height),
            Edge::Top => s.y - top,
            _ => 0,
        }
    }

    /// Where the window is along the edge, as a fraction of the screen.
    pub fn along(&self, vx: i32, vy: i32) -> f32 {
        let s = self.scr;
        if self.horizontal() {
            (vy - self.gy - s.y) as f32 / s.height.max(1) as f32
        } else {
            (vx - self.gx - s.x) as f32 / s.width.max(1) as f32
        }
    }

    /// Let go here: does the program move over (more than half of it is past the edge)?
    pub fn moved(&self, vx: i32, vy: i32) -> bool {
        self.crossed(vx, vy) * 2 > self.depth()
    }

    /// The pointer moved back just enough for the whole window to be on this screen.
    pub fn back_inside(&self, vx: i32, vy: i32) -> (i32, i32) {
        let c = self.crossed(vx, vy).max(0);
        match self.edge {
            Edge::Right => (vx - c, vy),
            Edge::Left => (vx + c, vy),
            Edge::Bottom => (vx, vy - c),
            Edge::Top => (vx, vy + c),
            _ => (vx, vy),
        }
    }

    /// The edge as a 0..1 position for `Crossed` (where the pointer goes over).
    pub fn frac(&self, vx: i32, vy: i32) -> f32 {
        let s = self.scr;
        let f = if self.horizontal() {
            (vy - s.y) as f32 / (s.height - 1).max(1) as f32
        } else {
            (vx - s.x) as f32 / (s.width - 1).max(1) as f32
        };
        f.clamp(0.0, 1.0)
    }
}

/// Where the window's top-left goes on the receiving screen.
pub fn place(v: &SpanView, scr: Screen) -> (i32, i32) {
    let (w, h) = (v.w as i32, v.h as i32);
    let ax = scr.x + (v.along * scr.width as f32).round() as i32;
    let ay = scr.y + (v.along * scr.height as f32).round() as i32;
    match v.entry {
        Edge::Left => (scr.x + v.crossed - w, ay),
        Edge::Right => (scr.x + scr.width - v.crossed, ay),
        Edge::Top => (ax, scr.y + v.crossed - h),
        Edge::Bottom => (ax, scr.y + scr.height - v.crossed),
        _ => (ax, ay),
    }
}

/// How much bigger things look on the receiving screen than on the sending one, so a
/// window keeps its size *relative to the screen* when it crosses between screens of
/// different resolution: for a left or right edge the screens' heights are compared
/// (they stand side by side), for a top or bottom edge their widths. Nearly equal
/// screens keep 1 so nothing goes soft for no reason.
pub fn scale_for(edge: Edge, send: (i32, i32), recv: (i32, i32)) -> f32 {
    let (a, b) = match edge {
        Edge::Top | Edge::Bottom => (send.0, recv.0),
        _ => (send.1, recv.1),
    };
    if a <= 0 || b <= 0 {
        return 1.0;
    }
    let k = (b as f32 / a as f32).clamp(0.5, 2.0);
    if (k - 1.0).abs() < 0.06 {
        1.0
    } else {
        k
    }
}

/// Scales a length by `k`.
pub fn sc(v: i32, k: f32) -> i32 {
    (v as f32 * k).round() as i32
}

/// How far past the edge the pointer may go while it drives a window across (the other
/// computer's screen, in this one's pixels; 0 until it is known).
static ROOM: std::sync::atomic::AtomicI32 = std::sync::atomic::AtomicI32::new(0);

pub fn set_room(px: i32) {
    ROOM.store(px.max(0), std::sync::atomic::Ordering::Relaxed);
}

pub fn room() -> i32 {
    ROOM.load(std::sync::atomic::Ordering::Relaxed)
}

/// A window crossing to the other computer, as shown there: sizes and distances of the
/// sender's `v` scaled by `k`.
pub fn scale_view(v: SpanView, k: f32) -> SpanView {
    if k == 1.0 {
        return v;
    }
    SpanView {
        crossed: sc(v.crossed, k),
        w: sc(v.w as i32, k).max(1) as u32,
        h: sc(v.h as i32, k).max(1) as u32,
        gx: sc(v.gx, k),
        gy: sc(v.gy, k),
        ..v
    }
}

/// Where the pointer is on the receiving screen for view `v` (its spot on the window).
pub fn pointer_at(v: &SpanView, scr: Screen) -> (i32, i32) {
    let (x, y) = place(v, scr);
    (
        (x + v.gx).clamp(scr.x, scr.x + scr.width - 1),
        (y + v.gy).clamp(scr.y, scr.y + scr.height - 1),
    )
}

/// `w` x `h` scaled down to fit in `max_w` x `max_h`, keeping its shape.
pub fn fit(w: u32, h: u32, max_w: u32, max_h: u32) -> (u32, u32) {
    if w <= max_w && h <= max_h {
        return (w.max(1), h.max(1));
    }
    let k = (max_w as f64 / w as f64).min(max_h as f64 / h as f64);
    (
        ((w as f64 * k).round() as u32).max(1),
        ((h as f64 * k).round() as u32).max(1),
    )
}

/// Resizes a 4-byte-per-pixel picture (nearest pixel; it is moving anyway).
pub fn scale4(src: &[u8], sw: u32, sh: u32, dw: u32, dh: u32) -> Vec<u8> {
    let (sw, sh, dw, dh) = (sw as usize, sh as usize, dw as usize, dh as usize);
    let mut out = vec![0u8; dw * dh * 4];
    if sw == 0 || sh == 0 || src.len() < sw * sh * 4 {
        return out;
    }
    let xs: Vec<usize> = (0..dw)
        .map(|x| (x * sw / dw.max(1)).min(sw - 1) * 4)
        .collect();
    for y in 0..dh {
        let row = (y * sh / dh.max(1)).min(sh - 1) * sw * 4;
        let o = &mut out[y * dw * 4..(y + 1) * dw * 4];
        for (x, &sx) in xs.iter().enumerate() {
            o[x * 4..x * 4 + 4].copy_from_slice(&src[row + sx..row + sx + 4]);
        }
    }
    out
}

/// BGRA (any alpha) to JPEG.
pub fn encode_jpeg(bgra: &[u8], w: u32, h: u32, quality: u8) -> Option<Vec<u8>> {
    if w == 0 || h == 0 || w > u16::MAX as u32 || h > u16::MAX as u32 {
        return None;
    }
    let mut out = Vec::with_capacity((w * h / 8) as usize);
    jpeg_encoder::Encoder::new(&mut out, quality)
        .encode(bgra, w as u16, h as u16, jpeg_encoder::ColorType::Bgra)
        .ok()?;
    Some(out)
}

/// JPEG to opaque BGRA. Refuses anything implausibly big (it comes over the network).
pub fn decode_jpeg(data: &[u8]) -> Option<(Vec<u8>, u32, u32)> {
    let mut d = jpeg_decoder::Decoder::new(data);
    d.read_info().ok()?;
    let info = d.info()?;
    let (w, h) = (info.width as u32, info.height as u32);
    if w == 0 || h == 0 || w > 4096 || h > 4096 {
        return None;
    }
    let px = d.decode().ok()?;
    let n = (w * h) as usize;
    let mut out = vec![255u8; n * 4];
    match info.pixel_format {
        jpeg_decoder::PixelFormat::RGB24 if px.len() >= n * 3 => {
            for i in 0..n {
                out[i * 4] = px[i * 3 + 2];
                out[i * 4 + 1] = px[i * 3 + 1];
                out[i * 4 + 2] = px[i * 3];
            }
        }
        jpeg_decoder::PixelFormat::L8 if px.len() >= n => {
            for i in 0..n {
                out[i * 4..i * 4 + 3].fill(px[i]);
            }
        }
        _ => return None,
    }
    Some((out, w, h))
}

/// The arrow pointer (premultiplied BGRA), its size and where its tip is.
pub fn arrow() -> (Vec<u8>, u32, u32, i32, i32) {
    // The same arrow the website draws: tip at (3, 2).
    const PTS: [(f32, f32); 7] = [
        (3.0, 2.0),
        (3.0, 24.0),
        (9.0, 18.6),
        (13.4, 28.0),
        (17.0, 26.4),
        (12.7, 17.2),
        (21.0, 17.0),
    ];
    let (w, h) = (24u32, 30u32);
    let inside = |x: f32, y: f32| {
        let mut c = false;
        let mut j = PTS.len() - 1;
        for (i, &(xi, yi)) in PTS.iter().enumerate() {
            let (xj, yj) = PTS[j];
            if (yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi {
                c = !c;
            }
            j = i;
        }
        c
    };
    let edge_dist = |x: f32, y: f32| {
        let mut best = f32::MAX;
        for (i, &(ax, ay)) in PTS.iter().enumerate() {
            let (bx, by) = PTS[(i + 1) % PTS.len()];
            let (dx, dy) = (bx - ax, by - ay);
            let t = (((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy)).clamp(0.0, 1.0);
            let (px, py) = (ax + t * dx - x, ay + t * dy - y);
            best = best.min((px * px + py * py).sqrt());
        }
        best
    };
    let mut out = vec![0u8; (w * h * 4) as usize];
    for y in 0..h {
        for x in 0..w {
            let (mut cover, mut white) = (0f32, 0f32);
            for sy in 0..4 {
                for sx in 0..4 {
                    let (fx, fy) = (
                        x as f32 + (sx as f32 + 0.5) / 4.0,
                        y as f32 + (sy as f32 + 0.5) / 4.0,
                    );
                    let near = edge_dist(fx, fy) < 1.1;
                    if inside(fx, fy) || near {
                        cover += 1.0 / 16.0;
                        if inside(fx, fy) && !near {
                            white += 1.0 / 16.0;
                        }
                    }
                }
            }
            // White body, dark outline (#0a1118), premultiplied.
            let a = cover.min(1.0);
            let (r, g, b) = (
                white * 255.0 + (a - white) * 10.0,
                white * 255.0 + (a - white) * 17.0,
                white * 255.0 + (a - white) * 24.0,
            );
            let i = ((y * w + x) * 4) as usize;
            out[i] = b.round() as u8;
            out[i + 1] = g.round() as u8;
            out[i + 2] = r.round() as u8;
            out[i + 3] = (a * 255.0).round() as u8;
        }
    }
    (out, w, h, 3, 2)
}

// ------------------------------------------------------------------ pointer shapes
//
// On a mirrored window the pointer looks the way it does on the real one: a text beam
// over text, a hand over links, resize arrows on the window's edges. The computer with
// the window says which standard shape it is (`Shape`); the one showing it draws it.

/// The standard pointer shapes, as sent (`u8`).
pub mod shape {
    pub const ARROW: u8 = 0;
    pub const TEXT: u8 = 1;
    pub const HAND: u8 = 2;
    pub const SIZE_WE: u8 = 3;
    pub const SIZE_NS: u8 = 4;
    pub const SIZE_NWSE: u8 = 5;
    pub const SIZE_NESW: u8 = 6;
    pub const SIZE_ALL: u8 = 7;
    pub const WAIT: u8 = 8;
    pub const NO: u8 = 9;
    pub const CROSS: u8 = 10;
}

static SHAPE: std::sync::atomic::AtomicU8 = std::sync::atomic::AtomicU8::new(0);

/// The shape the stand-in pointer takes from now on.
pub fn set_shape(s: u8) {
    SHAPE.store(s, std::sync::atomic::Ordering::Relaxed);
}

/// The shape the stand-in pointer has now.
pub fn current_shape() -> u8 {
    SHAPE.load(std::sync::atomic::Ordering::Relaxed)
}

enum Prim {
    /// A thick line: ends and half its thickness.
    Seg((f32, f32), (f32, f32), f32),
    /// A filled polygon.
    Poly(Vec<(f32, f32)>),
}

fn seg_dist(p: (f32, f32), a: (f32, f32), b: (f32, f32)) -> f32 {
    let (dx, dy) = (b.0 - a.0, b.1 - a.1);
    let l = dx * dx + dy * dy;
    let t = if l > 0.0 {
        (((p.0 - a.0) * dx + (p.1 - a.1) * dy) / l).clamp(0.0, 1.0)
    } else {
        0.0
    };
    let (qx, qy) = (a.0 + t * dx - p.0, a.1 + t * dy - p.1);
    (qx * qx + qy * qy).sqrt()
}

/// Signed distance to a primitive (negative inside).
fn prim_dist(p: (f32, f32), prim: &Prim) -> f32 {
    match prim {
        Prim::Seg(a, b, r) => seg_dist(p, *a, *b) - r,
        Prim::Poly(pts) => {
            let mut inside = false;
            let mut edge = f32::MAX;
            let mut j = pts.len() - 1;
            for i in 0..pts.len() {
                let (a, b) = (pts[i], pts[j]);
                if (a.1 > p.1) != (b.1 > p.1) && p.0 < (b.0 - a.0) * (p.1 - a.1) / (b.1 - a.1) + a.0 {
                    inside = !inside;
                }
                edge = edge.min(seg_dist(p, a, b));
                j = i;
            }
            if inside {
                -edge
            } else {
                edge
            }
        }
    }
}

/// A double-headed arrow along the x axis, `len` from the centre to each tip.
fn double_arrow(len: f32) -> Vec<Prim> {
    let head = 5.0;
    vec![
        Prim::Seg((-len + head, 0.0), (len - head, 0.0), 1.0),
        Prim::Poly(vec![(-len, 0.0), (-len + head, -head), (-len + head, head)]),
        Prim::Poly(vec![(len, 0.0), (len - head, -head), (len - head, head)]),
    ]
}

fn rotate(prims: Vec<Prim>, deg: f32) -> Vec<Prim> {
    let (s, c) = deg.to_radians().sin_cos();
    let r = |(x, y): (f32, f32)| (x * c - y * s, x * s + y * c);
    prims
        .into_iter()
        .map(|p| match p {
            Prim::Seg(a, b, t) => Prim::Seg(r(a), r(b), t),
            Prim::Poly(v) => Prim::Poly(v.into_iter().map(r).collect()),
        })
        .collect()
}

fn ring(radius: f32, t: f32) -> Vec<Prim> {
    (0..24)
        .map(|i| {
            let a0 = i as f32 / 24.0 * std::f32::consts::TAU;
            let a1 = (i + 1) as f32 / 24.0 * std::f32::consts::TAU;
            Prim::Seg(
                (radius * a0.cos(), radius * a0.sin()),
                (radius * a1.cos(), radius * a1.sin()),
                t,
            )
        })
        .collect()
}

/// The pointer for `s` (premultiplied BGRA), its size and its hot spot.
pub fn pointer_pic(s: u8) -> (Vec<u8>, u32, u32, i32, i32) {
    // Shapes are drawn around the centre of a 32 x 32 picture.
    let prims: Vec<Prim> = match s {
        shape::TEXT => vec![
            Prim::Seg((0.0, -8.0), (0.0, 8.0), 0.8),
            Prim::Seg((-3.5, -9.0), (3.5, -9.0), 0.8),
            Prim::Seg((-3.5, 9.0), (3.5, 9.0), 0.8),
        ],
        shape::HAND => vec![
            // Pointing finger, folded fingers, palm.
            Prim::Seg((-2.0, -11.0), (-2.0, 0.0), 2.0),
            Prim::Seg((1.6, -2.0), (1.6, 1.0), 1.8),
            Prim::Seg((5.0, -1.0), (5.0, 2.0), 1.8),
            Prim::Seg((8.2, 0.0), (8.2, 3.0), 1.7),
            Prim::Poly(vec![(-4.0, -1.0), (10.0, 1.0), (9.0, 9.0), (6.5, 12.0), (-1.0, 12.0), (-5.5, 6.0), (-8.0, 1.5), (-6.5, 0.0), (-4.0, 2.0)]),
        ],
        shape::SIZE_WE => double_arrow(10.0),
        shape::SIZE_NS => rotate(double_arrow(10.0), 90.0),
        shape::SIZE_NWSE => rotate(double_arrow(9.5), 45.0),
        shape::SIZE_NESW => rotate(double_arrow(9.5), -45.0),
        shape::SIZE_ALL => {
            let mut v = double_arrow(10.0);
            v.extend(rotate(double_arrow(10.0), 90.0));
            v
        }
        shape::WAIT => ring(7.0, 1.6),
        shape::NO => {
            let mut v = ring(7.0, 1.4);
            v.push(Prim::Seg((-5.0, 5.0), (5.0, -5.0), 1.4));
            v
        }
        shape::CROSS => vec![
            Prim::Seg((0.0, -10.0), (0.0, 10.0), 0.6),
            Prim::Seg((-10.0, 0.0), (10.0, 0.0), 0.6),
        ],
        _ => return arrow(),
    };
    let (w, h) = (32u32, 32u32);
    let (cx, cy) = (16.0f32, 16.0f32);
    let mut out = vec![0u8; (w * h * 4) as usize];
    for y in 0..h {
        for x in 0..w {
            let (mut cover, mut white) = (0f32, 0f32);
            for sy in 0..4 {
                for sx in 0..4 {
                    let p = (
                        x as f32 + (sx as f32 + 0.5) / 4.0 - cx,
                        y as f32 + (sy as f32 + 0.5) / 4.0 - cy,
                    );
                    let d = prims.iter().map(|q| prim_dist(p, q)).fold(f32::MAX, f32::min);
                    // White body, a dark outline 1.2 px wide around it.
                    if d < 1.2 {
                        cover += 1.0 / 16.0;
                        if d < 0.0 {
                            white += 1.0 / 16.0;
                        }
                    }
                }
            }
            let a = cover.min(1.0);
            let (r, g, b) = (
                white * 255.0 + (a - white) * 10.0,
                white * 255.0 + (a - white) * 17.0,
                white * 255.0 + (a - white) * 24.0,
            );
            let i = ((y * w + x) * 4) as usize;
            out[i] = b.round() as u8;
            out[i + 1] = g.round() as u8;
            out[i + 2] = r.round() as u8;
            out[i + 3] = (a * 255.0).round() as u8;
        }
    }
    let (hx, hy) = if s == shape::HAND { (14, 5) } else { (16, 16) };
    (out, w, h, hx, hy)
}

/// What the receiving side puts on screen: the picture at the window's size (or, until
/// the first picture arrives, a dim outline) with the pointer drawn where it holds it.
/// Premultiplied BGRA, `w` x `h`.
pub fn compose(frame: Option<(&[u8], u32, u32)>, w: u32, h: u32, gx: i32, gy: i32) -> Vec<u8> {
    let mut out = match frame {
        Some((px, fw, fh)) => {
            let mut v = scale4(px, fw, fh, w, h);
            for p in v.as_chunks_mut::<4>().0 {
                p[3] = 255;
            }
            v
        }
        None => {
            let mut v = vec![0u8; (w * h * 4) as usize];
            for y in 0..h {
                for x in 0..w {
                    let border = x < 2 || y < 2 || x + 2 >= w || y + 2 >= h;
                    let (c, a) = if border {
                        (140u8, 230u8)
                    } else {
                        (24u8, 150u8)
                    };
                    let pm = (c as u32 * a as u32 / 255) as u8;
                    let i = ((y * w + x) * 4) as usize;
                    v[i..i + 4].copy_from_slice(&[pm, pm, pm, a]);
                }
            }
            v
        }
    };
    let (ar, aw, ah, tx, ty) = arrow();
    for y in 0..ah as i32 {
        for x in 0..aw as i32 {
            let (dx, dy) = (gx - tx + x, gy - ty + y);
            if dx < 0 || dy < 0 || dx >= w as i32 || dy >= h as i32 {
                continue;
            }
            let s = ((y as u32 * aw + x as u32) * 4) as usize;
            let d = ((dy as u32 * w + dx as u32) * 4) as usize;
            let a = ar[s + 3] as u32;
            for c in 0..4 {
                out[d + c] = (ar[s + c] as u32 + out[d + c] as u32 * (255 - a) / 255) as u8;
            }
        }
    }
    out
}

/// How long the glow is along the edge, and how far it reaches into the screen.
pub const GLOW_LEN: i32 = 460;
pub const GLOW_DEPTH: i32 = 34;

/// The glow where the cursor crosses `edge` at `frac`: where it goes on the screen
/// (x, y, w, h) and its picture (premultiplied BGRA). Brightest at the edge and in the
/// middle, fading softly into the screen and towards both ends.
pub fn glow_strip(scr: Screen, edge: Edge, frac: f32, rgb: [u8; 3]) -> (i32, i32, i32, i32, Vec<u8>) {
    let f = frac.clamp(0.0, 1.0);
    let (len, d) = (GLOW_LEN, GLOW_DEPTH);
    let along_x = scr.x + (f * scr.width as f32) as i32 - len / 2;
    let along_y = scr.y + (f * scr.height as f32) as i32 - len / 2;
    let (right, bottom) = (scr.x + scr.width, scr.y + scr.height);
    // (x, y, w, h, is the glow horizontal, which side the screen edge is on)
    let (x, y, w, h, horiz, far) = match edge {
        Edge::Left => (scr.x, along_y, d, len, false, false),
        Edge::Right => (right - d, along_y, d, len, false, true),
        Edge::Top => (along_x, scr.y, len, d, true, false),
        Edge::Bottom => (along_x, bottom - d, len, d, true, true),
        // A corner: a round glow tucked into it.
        Edge::TopLeft => (scr.x, scr.y, len / 2, len / 2, true, false),
        Edge::TopRight => (right - len / 2, scr.y, len / 2, len / 2, true, false),
        Edge::BottomLeft => (scr.x, bottom - len / 2, len / 2, len / 2, true, false),
        Edge::BottomRight => (right - len / 2, bottom - len / 2, len / 2, len / 2, true, false),
    };
    let corner = edge.is_corner();
    let mut px = vec![0u8; (w * h * 4) as usize];
    for yy in 0..h {
        for xx in 0..w {
            let a = if corner {
                // Distance from the corner itself.
                let cx = if matches!(edge, Edge::TopLeft | Edge::BottomLeft) { 0 } else { w - 1 };
                let cy = if matches!(edge, Edge::TopLeft | Edge::TopRight) { 0 } else { h - 1 };
                let r = (((xx - cx) * (xx - cx) + (yy - cy) * (yy - cy)) as f32).sqrt() / w as f32;
                (1.0 - r).max(0.0).powi(3)
            } else {
                let (a_pos, a_len, depth) = if horiz { (xx, w, yy) } else { (yy, h, xx) };
                // 0 at the screen edge, 1 at the far side of the strip.
                let into = if far { (d - 1 - depth) as f32 } else { depth as f32 } / d as f32;
                let u = (a_pos as f32 / a_len as f32) * 2.0 - 1.0; // -1..1 along
                let along = (1.0 - u * u).max(0.0).powf(1.6);
                along * (-into * 3.2).exp() * (1.0 - into)
            };
            let a = (a * 0.85).clamp(0.0, 1.0);
            let i = ((yy * w + xx) * 4) as usize;
            px[i] = (rgb[2] as f32 * a) as u8;
            px[i + 1] = (rgb[1] as f32 * a) as u8;
            px[i + 2] = (rgb[0] as f32 * a) as u8;
            px[i + 3] = (a * 255.0) as u8;
        }
    }
    (x, y, w, h, px)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SCR: Screen = Screen {
        x: 0,
        y: 0,
        width: 2560,
        height: 1440,
    };

    fn right(w: i32) -> Geo {
        Geo {
            edge: Edge::Right,
            scr: SCR,
            w,
            h: 800,
            gx: 300,
            gy: 15,
        }
    }

    #[test]
    fn a_window_pushed_through_the_right_edge() {
        let g = right(1200);
        // The pointer at the edge, holding the window 300 px from its left: 899 px are past.
        let (vx, vy) = (2559, 400);
        assert_eq!(g.crossed(vx, vy), 899);
        // 640 px past the edge (the example from the chat): left edge at 2000.
        let vx = 2000 + 300;
        assert_eq!(g.crossed(vx, vy), 640);
        assert!(g.moved(vx, vy)); // 640 of 1200 is more than half
        assert!(!g.moved(2000 - 100 + 300, vy)); // 540 of 1200
                                                 // Can't go further than all of it on the other side.
        let (cx, _) = g.clamp(99_999, vy);
        assert_eq!(g.crossed(cx, vy), 1200);
        // Back inside: the window just touches the edge.
        let (bx, _) = g.back_inside(vx, vy);
        assert_eq!(g.crossed(bx, vy), 0);
        // Along: its top as a share of the screen.
        assert!((g.along(vx, 400) - (385.0 / 1440.0)).abs() < 1e-6);
    }

    #[test]
    fn the_other_screen_shows_the_part_past_the_edge() {
        // Sender's right edge = the receiver's left; the receiver is 1920x1080.
        let other = Screen {
            x: 0,
            y: 0,
            width: 1920,
            height: 1080,
        };
        let v = SpanView {
            entry: Edge::Left,
            crossed: 640,
            along: 0.5,
            w: 1200,
            h: 800,
            gx: 300,
            gy: 15,
        };
        // 640 px visible from the receiver's left edge, halfway down.
        assert_eq!(place(&v, other), (640 - 1200, 540));
        let v = SpanView {
            entry: Edge::Right,
            ..v
        };
        assert_eq!(place(&v, other), (1920 - 640, 540));
        let v = SpanView {
            entry: Edge::Top,
            along: 0.25,
            ..v
        };
        assert_eq!(place(&v, other), (480, 640 - 800));
        let v = SpanView {
            entry: Edge::Bottom,
            along: 0.25,
            ..v
        };
        assert_eq!(place(&v, other), (480, 1080 - 640));
    }

    #[test]
    fn every_edge_measures_its_own_way() {
        let g = Geo {
            edge: Edge::Left,
            scr: SCR,
            w: 1000,
            h: 600,
            gx: 100,
            gy: 10,
        };
        assert_eq!(g.crossed(100, 300), 0); // window's left on the edge
        assert_eq!(g.crossed(-400 + 100, 300), 400);
        let (cx, _) = g.clamp(-99_999, 300);
        assert_eq!(g.crossed(cx, 300), 1000);
        let g = Geo {
            edge: Edge::Top,
            scr: SCR,
            w: 1000,
            h: 600,
            gx: 100,
            gy: 10,
        };
        assert_eq!(g.crossed(500, 10 - 250), 250);
        assert!(!g.moved(500, 10 - 250));
        assert!(g.moved(500, 10 - 350));
        let g = Geo {
            edge: Edge::Bottom,
            scr: SCR,
            w: 1000,
            h: 600,
            gx: 100,
            gy: 10,
        };
        assert_eq!(g.crossed(500, 1440 - 600 + 10 + 200), 200);
        let (_, by) = g.back_inside(500, 1440 + 100);
        assert_eq!(g.crossed(500, by), 0);
    }

    #[test]
    fn pictures_survive_the_trip() {
        let (w, h) = (64u32, 40u32);
        let mut px = vec![0u8; (w * h * 4) as usize];
        for (i, p) in px.as_chunks_mut::<4>().0.iter_mut().enumerate() {
            // A blue left half and a red right half.
            let x = i as u32 % w;
            *p = if x < w / 2 {
                [200, 40, 30, 255]
            } else {
                [30, 40, 200, 255]
            };
        }
        let jpg = encode_jpeg(&px, w, h, FRAME_QUALITY).unwrap();
        let (back, bw, bh) = decode_jpeg(&jpg).unwrap();
        assert_eq!((bw, bh), (w, h));
        let at = |x: u32, y: u32| &back[((y * w + x) * 4) as usize..((y * w + x) * 4 + 4) as usize];
        assert!(at(5, 20)[0] > 150 && at(5, 20)[2] < 80, "blue stays blue");
        assert!(at(60, 20)[2] > 150 && at(60, 20)[0] < 80, "red stays red");
        assert!(decode_jpeg(b"not a picture").is_none());
    }

    #[test]
    fn scaling_and_fitting() {
        assert_eq!(fit(2560, 1440, FRAME_MAX_W, FRAME_MAX_H), (1280, 720));
        assert_eq!(fit(800, 600, FRAME_MAX_W, FRAME_MAX_H), (800, 600));
        assert_eq!(fit(1000, 3000, FRAME_MAX_W, FRAME_MAX_H), (300, 900));
        let src = [1, 2, 3, 4, 5, 6, 7, 8]; // 2x1
        assert_eq!(
            scale4(&src, 2, 1, 4, 1),
            vec![1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 8, 5, 6, 7, 8]
        );
    }

    #[test]
    fn the_glow_hugs_the_edge_where_the_cursor_crossed() {
        let (x, y, w, h, px) = glow_strip(SCR, Edge::Right, 0.5, [45, 212, 191]);
        assert_eq!((x, w, h), (2560 - GLOW_DEPTH, GLOW_DEPTH, GLOW_LEN));
        assert_eq!(y, 720 - GLOW_LEN / 2);
        let a = |xx: i32, yy: i32| px[((yy * w + xx) * 4 + 3) as usize];
        // Brightest at the screen edge (the right side of the strip), in the middle.
        assert!(a(w - 1, h / 2) > 150);
        assert!(a(0, h / 2) < 30, "fades into the screen");
        assert!(a(w - 1, 2) < 10, "fades towards the ends");
        // The colour, premultiplied: teal-ish at the brightest point.
        let i = (((h / 2) * w + w - 1) * 4) as usize;
        assert!(px[i + 1] > px[i + 2], "more green than red");
        let (x, y, _, _, _) = glow_strip(SCR, Edge::Top, 0.25, [255, 255, 255]);
        assert_eq!((x, y), (640 - GLOW_LEN / 2, 0));
    }

    #[test]
    fn the_pointer_is_drawn_where_the_window_is_held() {
        let out = compose(None, 100, 80, 50, 40);
        // The arrow's white body just below and right of its tip.
        let i = ((46 * 100 + 52) * 4) as usize;
        assert!(
            out[i] > 200 && out[i + 3] == 255,
            "white pointer body at the hold point"
        );
        // Far from it: the dim outline / inside.
        assert!(out[((70 * 100 + 10) * 4) as usize + 3] < 255);
        let (a, w, h, tx, ty) = arrow();
        assert_eq!((w, h, tx, ty), (24, 30, 3, 2));
        assert_eq!(a[3], 0, "corner is transparent");
    }

    #[test]
    fn a_window_carries_on_across_the_other_screen_once_fully_over() {
        let g = right(400);
        let s = g.scr;
        let edge = s.x + s.width;
        // Without room: stuck once fully over.
        assert_eq!(g.clamp(edge + 5000, 300).0, edge + g.gx);
        // With the other screen known: up to its far side.
        assert_eq!(g.clamp_room(edge + 5000, 300, 1500).0, edge + 1500);
        assert!(g.crossed(edge + 1500, 300) > g.w);
    }

    #[test]
    fn screens_of_other_sizes_scale_windows() {
        assert_eq!(scale_for(Edge::Right, (1920, 1080), (1920, 1080)), 1.0);
        assert_eq!(scale_for(Edge::Right, (3840, 2160), (1920, 1080)), 0.5);
        assert_eq!(scale_for(Edge::Right, (1366, 768), (2560, 1440)), 1.875);
        // Two monitors side by side on one computer don't matter for a left/right edge.
        assert_eq!(scale_for(Edge::Left, (3840, 1080), (1920, 1080)), 1.0);
        assert_eq!(scale_for(Edge::Top, (1920, 1080), (1920, 1200)), 1.0);
        let v = SpanView { entry: Edge::Left, crossed: 100, along: 0.2, w: 800, h: 600, gx: 40, gy: 10 };
        let s = scale_view(v, 0.5);
        assert_eq!((s.crossed, s.w, s.h, s.gx, s.gy), (50, 400, 300, 20, 5));
    }

    #[test]
    fn every_pointer_shape_draws() {
        for s in 0..=10u8 {
            let (px, w, h, hx, hy) = pointer_pic(s);
            assert_eq!(px.len(), (w * h * 4) as usize);
            assert!(hx >= 0 && hy >= 0 && hx < w as i32 && hy < h as i32);
            assert!(px.chunks(4).any(|p| p[3] == 255), "shape {s} is visible");
        }
        // Unknown shapes are the arrow.
        assert_eq!(pointer_pic(200).1, arrow().1);
    }
}

